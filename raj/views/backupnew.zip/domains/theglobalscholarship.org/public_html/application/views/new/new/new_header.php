<!DOCTYPE html>
<html lang="zxx">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <!--========= Basic Page Needs =========-->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta property="og:type"               content="The Global Scholarship" />
  <meta property="og:title"              content="Scholarships At Your Fingertips" />
  <meta property="og:description"        content="TGS - A smart scholarships alert engine which matches your profile with the scholarship's criteria and sends you alerts on mobile. " />
  <meta property="og:image"              content="<?php echo base_url()?>assets/img/brand/sc logo.png" />
  <!--======== Page Title===========-->
  <title>The Global Scholarship</title>
  <!--========== Favicons =========-->
  <link rel="shortcut icon" sizes="70x70" href="<?php echo base_url();?>website_assets/sc logo.png">
  <!--======== Font icon Css ============-->
  <!--<link href="<?php echo base_url();?>website_assets/css/font-awesome.min.css" rel="stylesheet">-->
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
  <link href="<?php echo base_url();?>website_assets/css/themify-icons.css" rel="stylesheet">
  <!--======= Bootstrap Main Css =============-->
  <link href="<?php echo base_url();?>website_assets/css/bootstrap.min.css" rel="stylesheet">
  <!--====== Plugins Css ================-->
  <link href="<?php echo base_url();?>website_assets/css/plugins.css" rel="stylesheet">
  <!--====== intern Css ================-->
 <!--  <link href="<?php echo base_url();?>assets/css/newtgs.css" rel="stylesheet"> -->


  <!-- new testimonial carousel css -->
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.1/assets/owl.carousel.min.css">
  <link rel="stylesheet" type="text/css" href="https://themes.audemedia.com/html/goodgrowth/css/owl.theme.default.min.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>website_assets/new/new.css">

  
  <!-- Multislider css -->
  <link href="<?php echo base_url();?>/assets/plugins/multislider/multislider.css" rel="stylesheet">
  <!-- cash icon source-->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/iconfonts/ionicons/ionicons.css">
  <!-- social media icons css link below-->
  <!-- <link rel="stylesheet" href="<?php echo base_url();?>/assets/iconfonts/simple-line-icons/simple-line-icons.css"> -->
  <!-- Scholarship deatails page css-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>/assets/css/style.css">
  <!--====== Custom CSS for themes =======-->
  <link href="<?php echo base_url();?>website_assets/style.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo base_url();?>website_assets/build/css/intlTelInput.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
  <link href="<?php echo base_url();?>website_assets/tags.css" rel="stylesheet" />
  <link href="<?php echo base_url();?>website_assets/css/perfect-scrollbar.css" rel="stylesheet" />
  <link href="<?php echo base_url();?>website_assets/css/tables.css" rel="stylesheet" />
  <link href="<?php echo base_url();?>website_assets/css/amabassador.css" rel="stylesheet" />
  <link href="<?php echo base_url();?>website_assets/css/floating-button.css" rel="stylesheet" />
    <!--[if lt IE 8]>
    <![endif]-->
    <!-- jQuery Latest Version -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/testimonial/css/plugins/animate.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/testimonial/css/plugins/swiper-bundle.min.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/testimonial/css/plugins/aos.css" />
    <link rel="stylesheet" href="<?php echo base_url();?>assets/testimonial/css/plugins/selectric.css" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/css/bootstrapValidator.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo base_url();?>website_assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.5.3/js/bootstrapValidator.js"></script>


    <!-- Switcher css-->
    <link href="<?php echo base_url();?>assets/switcher/css/switcher.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/switcher/demo.css" rel="stylesheet">
    <script>
      window.smartlook||(function(d) {
        var o=smartlook=function(){ o.api.push(arguments)},h=d.getElementsByTagName('head')[0];
        var c=d.createElement('script');o.api=new Array();c.async=true;c.type='text/javascript';
        c.charset='utf-8';c.src='https://rec.smartlook.com/recorder.js';h.appendChild(c);
      })(document);
      smartlook('init', '6fbe985a968f9a076a6a942a91ee9df06341f130');
    </script>
    <script>
      $(function () {
        $('[data-toggle="tooltip"]').tooltip()
      })
    </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-T1Y2L3C6VT"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      
      gtag('config', 'G-T1Y2L3C6VT');
    </script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
    crossorigin="anonymous"></script>
     <style>
      .icon-bar {
        position: fixed;
        top: 50%;
        z-index:50;
        -webkit-transform: translateY(-50%);
        -ms-transform: translateY(-50%);
        transform: translateY(-50%);
      }
      .icon-bar a {
        display: block;
        text-align: center;
        padding: 10px;
        transition: all 0.3s ease;
        color: white;
        font-size: 20px;
        background-color:#ff7f45;
      }
      .icon-bar a:hover {
        background-color: #000;
      }
      .facebook {
        background: #3B5998;
        color: white;
      }
      .twitter {
        background: #55ACEE;
        color: white;
      }
      .google {
        background: #dd4b39;
        color: white;
      }
      .linkedin {
        background: #007bb5;
        color: white;
      }
      .youtube {
        background: #bb0000;
        color: white;
      }
    </style>
    <style>
      .reg-button:hover {
        animation-name: shakeAnim;
      }
      @keyframes shakeAnim {
        0% {left: 0}
        1% {left: -3px}
        2% {left: 5px}
        3% {left: -8px}
        4% {left: 8px}
        5% {left: -5px}
        6% {left: 3px}
        7% {left: 0}
      }
      @keyframes shake {
        0% {left: 0}
        1% {left: -3px}
        2% {left: 5px}
        3% {left: -8px}
        4% {left: 8px}
        5% {left: -5px}
        6% {left: 3px}
        7% {left: 0}
      }
    </style>
    <style type="text/css">
      .registerbutton{
        font-size: 14px;
        display: inline-block;
        background: #F2B625;
        color: #41044D;
        /*background-color:#FF854E;*/
        text-transform: uppercase;
        padding: 5px 10px;
        border-radius: 10px;
        border-color:#F2B625;
        box-shadow: 0px 10px 5px -5px rgba(0,0,0,0.4);
        cursor: pointer;
        transition: all ease-in-out 300ms;
      }
      ul, li {
          color:#fff !important;
      }
    </style>
    <style type="text/css">
     .registerbutton:hover{
      background:#ffffff;
      box-shadow: 0px 37px 20px -20px rgba(0,0,0,0.2);
      transform: translate(0px, -10px) scale(1.2);
    }
    @media only screen and (max-width: 600px) {
      .registerbutton:hover
      {
       box-shadow: 0px 37px 20px -20px rgba(0,0,0,0.2);
       transform: translate(0px, -10px) scale(1.0);
            }
            
           .section-heading {
        font-size: 25px;
    }
   }  
   @media only screen and (max-width: 767px)
.section-heading {
    font-size: 25px;
}
 </style>
 <!--====Asif intern css start from below Area ====================================-->
 <style>
   .number{
    padding-left: 30px;
    padding-right: 30px;
    padding-top: 50px;
    padding-bottom: 50px;
    background-color: #ff7f45;
    margin-right: 10px;
    border-radius: 14px;
    color: white;
    font-size: 30px;
    font-weight: bold;
  }
  /* new clss added to 33cr number*/
  .num{
    padding-left: 20px;
    padding-right: 30px;
    padding-top: 50px;
    padding-bottom: 50px;
    background-color: #ff7f45;
    margin-left: 10px;
    border-radius: 14px;
    color: white;
    font-size: 30px;
    font-weight: bold;
  }
  .btn-primary:hover {
    border-color: #ff7f45;
  }
</style>
<style>
  @media screen and (max-width: 650px) {
    section {
     padding: 10px 5px 20px 5px ;
     display: block;
   }
   .displayButton{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
  .watchLink{
    margin: 10px;
  }
  .Add{
    margin-top: 5px;
    height: 260px;
    width: 100%;
    background-image: url('assets/images/add/ads-logo.png');
    background-size: 100% 100%; 
  }
  .number,.num{
    display: block;
  }
  .count{
  display: none;
}

  .states{
    margin-top: 10px; 
    height: 350px;
    width: 100%; 
    background-image: url('assets/images/add/ads-logo.png'); 
    background-size: 100% 100%;
  }
  .Add1{
    margin-top: 10px;
    height: 260px;
    width: 100%;
    background-image: url('assets/images/add/ads-logo.png');
    background-size: 100% 100%;
  }
  .add{
    display: none;
  }
  .card-height{
  height: auto;
}
.card-h6-content{
  display: flex;
  justify-content:left;
  align-items: center;
   margin: 5px;
   font-weight: 500;
   font-size: 16px;
}
.font{
  font-size: 17px;
  letter-spacing: 0; 
  text-transform:capitalize;
}
.icon-margin{
    margin-right: 15px; 
}
.dekstop-card{
  display: none;
}
.footer-top-area{
  background-color: #ff7f45;
  padding: 15px 0;
}
.icon_aTop{
  border-top-right-radius:10px; 
}
.icon_aBottom{
  border-bottom-right-radius:10px; 
}
}
@media screen and (min-width: 650px) {
  section {
   padding: 10px 40px 20px 40px ;
   display: flex;
 }
 .displayButton{
  display: flex;
  justify-content: center;
  align-items: center;
}
.watchLink{
  margin-left: 10px;
}
.indent{
  text-indent: 21rem;
}
.justify{
  text-align: justify;
}
.count{
  display: none;
}
.Add{
  margin-top: 64px;
  background-color: #ff7f45;
  height: 260px;
  width: 300px;
  background-image: url('assets/images/add/ads-logo.png');
  background-size: 100% 100%; 
}
.states{
  margin-top: 10px; 
  background-color: #ff7f45;
  height: 350px;
  width: 300px; 
  background-image: url('assets/images/add/ads-logo.png'); 
  background-size: 100% 100%;
}
.Add1{
  margin-top: 64px;
  background-color: #ff7f45;
  height: 650px;
  width: 300px;
  background-image: url('assets/images/add/ads-logo.png');
  background-size: 100% 100%;
}
.card-height{
  height: auto;
}
.card-content{
  display: flex;
  flex-wrap: wrap;
}
.card-h6-content{
  display: flex;
  justify-content:left;
  align-items: center;
   margin:0 5px 1px 5px;
   font-weight: 500;
}
.font{
  font-size: 15px;
  letter-spacing: 0; 
  text-transform:capitalize;
}
.mobile-card{
  display: none;
}
.footer-top-area{
  background-color: #ff7f45;
  padding: 35px 0;
}
.icon_aTop{
  border-top-right-radius:10px; 
}
.icon_aBottom{
  border-bottom-right-radius:10px; 
}
}
</style>
<style>
 @media screen and (max-width: 650px) {
  header {
   margin-bottom: 30px;
 }
}
@media screen and (min-width: 650px) {
  header {
    margin-bottom: 100px;
  }
}
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: #480057;
  color: white;
  cursor: pointer;
  padding-bottom: 6px;
  padding-top: 6px;
  padding-right: 15px;
  padding-left: 15px;
  border-radius: 4px;
  font-weight: bold;
}
.ion { 
    size:10px;
font-weight: bold;
}
.mobile-logo {
    position: absolute;
    top: 0px;
    z-index: 999999;
    left: 10;
    height: 100%;
    display: block;
    width: 50%;
}
</style> 
<!--====Asif intern css end ====================================-->
  </head>
  <body >
        <a id="myBtn"  style="font-weight: bold;"><i class="ion ion-ios7-arrow-thin-up" ></i></a>
   <!-- <div class="icon-bar">-->
   <!--  <a class="icon_aTop" href="https://www.instagram.com/the_global_scholarship/" target=_blank class="instagram">   <i class="fa fa-instagram"></i></a>-->
   <!--  <a href="https://www.facebook.com/theglobalscholarship/" target=_blank class="facebook"><i class="fa fa-facebook"></i></a> -->
   <!--  <a href="https://www.youtube.com/c/theglobalscholarshiporg" target=_blank class="youtube"><i class="fa fa-youtube-play"></i></a> -->
   <!--  <a class="icon_aBottom" href="https://t.me/theglobalscholarship" target=_blank class="twitter"><i class="fa fa-telegram"></i></a> -->


   <!--</div>-->
   <!-- Switcher -->

   <!-- End Switcher -->
  <!-- <?php if(!$this->uri->segment(1) == 'student-register'){?>-->

  <!--  <ul class="ulStart">-->


  <!--    <li class="liStart" >-->
  <!--      <a   target = "_blank" href="https://api.whatsapp.com/send/?phone=+919916056303&text=Hello The Global Scholarship Team, Please let me know more about your Scholarship Services as I am interested to enroll for your services. . . I Got Your Contact from your portal...." data-action="share/whatsapp/share"style="background-color: green">-->
  <!--        <i class="fa fa-whatsapp my-float"></i>-->
  <!--      </a>-->
  <!--    </li>-->
  <!--  </ul>-->

  <!--<?php }?>-->

  <!--====Header Area ====================================-->
  <header id="site-header" class="header-area" >

    <div class="header-inner"id="sticky" style="background-color:#41044D">
         <!-- <div class="focus" style="background: #ff7f45;height:6px"></div>
           <div class="socio" align="right" style="background: #ff7f45;color:#33363C; padding-right:24px; height: 27px;">Follow us on&nbsp;<i class="target fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;<a href="https://instagram.com/the_global_scholarship" target="_blank"> <i class="fa fa-instagram" style="color:#33363C" aria-hidden="true"></i> </a> <a href="https://www.facebook.com/theglobalscholarship" target="_blank"> <i class="fa fa-facebook" style="color:#33363C" aria-hidden="true"></i> </a><a href="https://t.me/theglobalscholarship" target="_blank"><i class="fa fa-telegram" style="color:#33363C" aria-hidden="true"></i></a> <a href="https://www.youtube.com/channel/UC_kmviAHHhyZYESlhRPoKuw" target="_blank"><i class="fa fa-youtube" style="color:#33363C" aria-hidden="true"></i></a> for updates</div> -->

           <div class="container-fluid">
            <div class="row">
              <div class="col-lg-12">
                <div class="logo-menu-wrap hidden-xs hidden-sm">
                  <div class="logo">
                    <a href="<?php echo base_url();?>">
                      <img src="<?php echo base_url();?>website_assets/sc logo.png" alt="logo" style="max-width:125px;margin-left:60px">
                    </a>
                  </div><!--/.logo-->
                  <nav class="menu">
                    <ul id="nav">

                      <li><a href="<?php echo base_url();?>">home</a></li>
                      <?php if($this->uri->segment(1) != 'about-us'){?>
                      <li><a href="<?php echo base_url();?>about-us">About us</a></li>
                   <?php }?>
                      <!--<li><a href="<?php echo base_url();?>contact-us">contact us</a></li>-->
                      <?php if($this->session->userdata('student_username')){ 
                        ?>
                        <li class="dropdown-trigger"><a href="#"><?php echo $this->session->userdata('student_name');?></a>
                          <ul class="dropdown-content" style="width: 115% !important;">
                           
                            
                             <li><a href="<?php echo base_url();?>student-home">Dashboard</a></li>
                              
                         
                           <li><a href="<?php echo base_url();?>logout">Logout</a></li>
                         </ul>
                       </li>
                     <?php }else{?>

                       <?php if(!$this->uri->segment(1)){?>
                                
                        <li><a href="<?php echo base_url();?>student-login">Login</a></li>
                        <!--style= 'color: #fff; background-color:#480057;'-->
                        <li style="padding:0 px !important"><a align="right" class="btn registerbutton"  href="<?php echo base_url();?>student-register">Register</a></li>
                      <?php }?>
                    <?php }?>
                  </ul>
                </nav><!--/.menu-->
              </div><!--/.logo-menu-wrap-->
            </div><!--/.col-lg-12-->
          </div><!--/.row-->
        </div><!--/.container-fluid-->
      </div><!--/.headier-inner-->
      <style>
        #sticky {
          position: fixed;
          top: 0;
          width: 100%;
          z-index:9999;
          background-color:#ffff;

        }
      </style>
      <!-- <div id=""><div class="focus" style="background: #ff7f45;height:6px"></div>-->
      <!--<div class="socio" align="right" style="background: #ff7f45;color:#33363C; padding-right:24px; height: 27px;">Follow us on&nbsp;<i class="target fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;<a href="https://instagram.com/the_global_scholarship" target="_blank"> <i class="fa fa-instagram" style="color:#33363C" aria-hidden="true"></i> </a> <a href="https://www.facebook.com/theglobalscholarship" target="_blank"> <i class="fa fa-facebook" style="color:#33363C" aria-hidden="true"></i> </a><a href="https://t.me/theglobalscholarship" target="_blank"><i class="fa fa-telegram" style="color:#33363C" aria-hidden="true"></i></a> <a href="https://www.youtube.com/channel/UC_kmviAHHhyZYESlhRPoKuw" target="_blank"><i class="fa fa-youtube" style="color:#33363C" aria-hidden="true"></i></a> for updates</div>-->
      <!--Mobile Menu-->

      <div class="mobile-menu"id="sticky" style="background-color:#41044D !important">
            <!-- <div class="focus" style="background: #ff7f45;height:6px"></div>
              <div class="socio" align="right" style="background: #ff7f45;color:#33363C; padding-right:24px; height: 27px;">Follow us on&nbsp;<i class="target fa fa-hand-o-right" aria-hidden="true"></i>&nbsp;<a href="https://instagram.com/the_global_scholarship" target="_blank"> <i class="fa fa-instagram" style="color:#33363C" aria-hidden="true"></i> </a> <a href="https://www.facebook.com/theglobalscholarship" target="_blank"> <i class="fa fa-facebook" style="color:#33363C" aria-hidden="true"></i> </a><a href="https://t.me/theglobalscholarship" target="_blank"><i class="fa fa-telegram" style="color:#33363C" aria-hidden="true"></i></a> <a href="https://www.youtube.com/channel/UC_kmviAHHhyZYESlhRPoKuw" target="_blank"><i class="fa fa-youtube" style="color:#33363C" aria-hidden="true"></i></a> for updates</div> -->

              <div class="row" >
                <div class="col-lg-12" >
                  <div class="mobile-logo" style="width:20px">
                    <a href="<?php echo base_url();?>">
                      <img src="<?php echo base_url();?>website_assets/sc logo.png" alt="logo" style="max-width:100px;margin-left:10px">
                    </a>
                  </div>
                  <div class="float-right" style="padding:20px;">
                    <?php if($this->session->userdata('student_username')){ 
                      ?>
                      <?php if($this->session->userdata('student_username')){ ?>
                       <a href="<?php echo base_url();?>student-home">
                        <button class="btn registerbutton btn-sm"style="font-size:12px">Dashboard</button> </a>
                      <?php }?>
                      <a href="<?php echo base_url();?>logout">
                        <button class="btn registerbutton btn-sm"style="font-size:12px">Logout</button></a>
                      <?php }else{?>
                       <?php if(!$this->uri->segment(1)){?>
                       <a style="color:#fff" class="hyperlink" href="<?php echo base_url();?>about-us">About us</a>
                        <a style="color:#fff" class="hyperlink" href="<?php echo base_url();?>student-login">Login</a>
                        <a href="https://scholar.theglobalscholarship.org/student-promotion-register">
                          <button class="btn registerbutton btn-sm">Register</button></a>
                        <?php }else if($this->uri->segment(1)){?>
                          <a style="color:#fff" class="hyperlink" href="<?php echo base_url();?>">Home </a>                    
                          <a style="color:#fff" class="hyperlink" href="<?php echo base_url();?>about-us">About us</a>
                    
                          <?php }?>
                        <?php }?>

                        
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </header><!--/.header-area-->
          <script>
            $(window).scroll(function() {
              if ($(this).scrollTop() > 0) {
                $('.socio').fadeOut();
              } else {
                $('.socio').fadeIn();
              }
            });
          </script>
             <script>
             var btn = $('#myBtn');

$(window).scroll(function() {
  if ($(window).scrollTop() > 20) {
    btn.addClass('show');
  } else {
    btn.removeClass('show');
  }
});

btn.on('click', function(e) {
  e.preventDefault();
  $('html, body').animate({scrollTop:0}, '20');
});



</script>