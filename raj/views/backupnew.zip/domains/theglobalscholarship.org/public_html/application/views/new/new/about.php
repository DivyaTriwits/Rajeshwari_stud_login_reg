
<!--/.page-heading-area-->
<!--====================================Ambassador Section====================================-->
<section id="services-section" class="services-section-area s-pd1" style="background: #ffff !important; padding-bottom:18px">
   <div class="container">
      <div class="row justify-content-md-center">
         <div class="col-lg-12">
            <h1 class="">About Us</h1>
            <br>
            <div class="row">
            <div class="col-lg-8">
            <p style="line-height:1.8rem ">
               Global scholarship is intended to benefit the student financially and make them independent during their education. A team at the global scholarship is dedicatedly working towards getting scholarship details and curetting it and posting on the portal just with an intention of benefiting the students with all the information and application process.
            </p>
            
            <p style="line-height:1.8rem ">
                We at TheGlobalScholarship.org are into the field of exploring the scholarship and here for maintaining a curetted database for the society. The intention of TheGlobalScholarship.org is to provide a proper channel for parents and students to financially aid in studies.
            </p>
            </div>
            <div class="col-lg-4">
           
                    <iframe  width="100%" height="300" src="https://www.youtube.com/embed/HAMmNg0LPCw" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                
            </div>
            </div>
             <div class="">
               
               <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="4041077001"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
            </div>
            
            <div class="responsibilities">
               <h1 class="">Mission</h1>
               <!--<h3 class="page-heading" style="color: #ff7f45;">Ambassador</h3>-->
               <p class="" style="line-height:1.8rem ">
                 To support 1 million students benefit financially in their studies by getting scholarship.
               </p>
             
             
               
                      
                     <img src="<?php echo base_url()?>assets/images/about2.png" alt="Branding-Img" >
                   
            </div>
            <div class="responsibilities">
               <h1 class="">Vision</h1>
               <!--<h3 class="page-heading" style="color: #ff7f45;">Structure</h3>-->
               <p class="" style="line-height:1.8rem ">
                 To benefit maximum students to achieve almost free education. 
               </p>
               <br>
               <h1 class="">Our process: </h1>
               <ul align="" style="line-height:1.8rem ">
                   <li>
                       1.	A team dedicatedly curates the available scholarship by crosschecking facts and verifying with the concerned authorities. 
                   </li>
                   <li>2.	Segregates every details required for students for filling up the application form. </li>
                   <li>3.	Post on our portal and benefit of students.</li>
                   <li>4.	Notify student via mail, message, and application notification</li>
                   <li>5.	We make sure that every details of scholarships will be posted on our  <a href="https://www.instagram.com/the_global_scholarship/" target=_bank><u style="color:blue">Instagram page</u></a>, Follow us for more updates</li>
               </ul>
               <br>
               <!--<p align="">(We make sure each details regarding scholarships will be posted on our TGS Instagram page)</p>-->
              
            </div>
            
         </div>
      </div>
   </div>
</section>

<section id="contact services-section " class="services-section-area s-pd1" style="background: #ffff !important; padding-top:10px !important">
   <div class="container" id="contact">
      <div class="row justify-content-md-center">
         <div class="col-lg-12">
           
             <!-- About us - Responsive 1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="1941527275"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
            
          
            
         </div>
      </div>
   </div>
</section>

<section id="contact services-section " class="services-section-area s-pd1" style="background: #ffff !important; padding-top:10px !important">
   <div class="container" id="contact">
      <div class="row justify-content-md-center">
         <div class="col-lg-12">
           
            <div >
                <h1 class="">Why to Choose Us.?
 </h1>
               <ul align="" style="line-height:1.8rem ">
                <li>  1.	Application start date notification.</li>
                 <li> 2.	Required document check list.</li>
                 <li> 3.	Proper channel for application.</li>
                 <li> 4.	Simplified application process.</li>
                 <li> 5.	Form filling support for students.</li>
                 <li> 6.	Application Process Video on YouTube, Subscribe to our <a href="https://www.youtube.com/c/theglobalscholarshiporg" target=_bank><u style="color:blue">YouTube</u></a> Channel.</li>
                 <li> 7.	Regular reminders.</li>
                 <li> 8.	SMS notification.</li>
                 <li> 9.	Custom E-mail notification.</li>
                 <li> 10.	Dedicate support for student. </li>
                 <li> 11.	Reminder notification before application end date.</li>

               </ul>
               
            </div>
            
          
            
         </div>
      </div>
   </div>
</section>