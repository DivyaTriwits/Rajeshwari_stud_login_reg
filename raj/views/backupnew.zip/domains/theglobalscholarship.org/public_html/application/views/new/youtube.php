<!--<script -->
<!--        src="https://code.jquery.com/jquery-git.js">-->
<!--    </script>-->
<div align="" style="padding:400px 0 0 250px">
    <img src="<?php echo base_url();?>website_assets/sc logo.png" alt="logo" style="max-width:500px;">
    </div>
     
       <!--<a href="intent://channel/UC_kmviAHHhyZYESlhRPoKuw/#Intent;scheme=vnd.youtube;package=com.google.android.youtube;S.browser_fallback_url=market://details?id=com.google.android.youtube;end;"> <button>Redirect me to GFG</button></a>-->
   

<script>
setTimeout(function() {
  window.location.href = "intent://channel/UC_kmviAHHhyZYESlhRPoKuw/#Intent;scheme=vnd.youtube;package=com.google.android.youtube;S.browser_fallback_url=market://details?id=com.google.android.youtube;end;";
}, 100);
</script>