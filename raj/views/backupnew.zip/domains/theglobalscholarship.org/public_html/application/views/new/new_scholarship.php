<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
crossorigin="anonymous"></script>

<section id="courses-section" class="popular-courses-area " >
	<div class="container" >
		<div class="row justify-content-md-center">
			<div class="col-lg-12">
				<div class="text-center">
					<h1 class="text-capitalize section-heading" style="margin-top: 60px"><?php 
					$scholarshipsCategory = str_replace('%20', ' ', $this->uri->segment(2));
					echo $scholarshipsCategory?> </h1>
				</div>
				<!--/.section-heading-area--> 
			</div>
			<!--/.col-lg-8-->
		</div>
			<div class="Addbox text-center mobile-card" style="margin: 10px 0px;">
<ins class="adsbygoogle"
     style="display:inline-block;width:280px;height:200px"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="9960188913"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
		<div class="row">
			<?php $index =1; $node=1; foreach($scholarships as $value): 
			    
			    if($node == 1){
			        $node+=2;
			    }
			    
			?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12">
				<a href="<?php echo base_url('scholarships-details/'.$value->scholarship_id)?>">
				<div class="card card-height" style="height:120px !important">
						<div class="row" style="padding-top:20px;padding-left:12px">
						<div class="col-3">
							<div style="background-color: #ff7f45; border-radius: 5px ; padding:12px;color:#fff; height:78px !important; width:75px !important" align="center">
							<h5 style="color:#fff"><?php $str= $value->application_end_date;
							$newdata = date("d", strtotime($str));
							echo $newdata; 
							
						?></h5>
						<h5 style="color:#fff"><?php $str= $value->application_end_date;
							$month =date("F", strtotime($str));
							$result = substr($month, 0, 3);
							echo $result;
						?></h5>
						<p style="font-size:10px;padding-bottom:2px">Last Date</p>
					</div>
						</div>
						<div class="col-9">
						    <div style="padding-top:10px !important">
							<h6 class="addReadMore showlesscontent">
						    								<?php echo $value->scholarship_name;?>
						</h6>
						</div>
						</div>
					</div>
			
				</div>
			</a>
			</div>
			
			<?php if($index == $node){?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12 mobile-ad" style="display:none" align="center">
<!--			    <ins class="adsbygoogle"-->
<!--     style="display:inline-block;width:270px;height:100px"-->
<!--     data-ad-client="ca-pub-8408941960924322"-->
<!--     data-ad-slot="1362461550"></ins>-->
<!--<script>-->
<!--     (adsbygoogle = window.adsbygoogle || []).push({});-->
<!--</script>-->
			<ins class="adsbygoogle"
     style="display:inline-block;width:280px;height:100px !important"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="9960188913"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
			</div>
		
			<?php $node+=3;}?>
			<?php $index++; endforeach; ?>
		</div>

	</div>	
	<style>
	@media (max-width : 480px){
	    .mobile-ad{
	     display:block !important;  
	     width:auto;
	    
	    }
	}
	    
	</style>
	<div  class="addbox" id="fadd">
		<div class="Add" style="">
			<!-- screen 2 - Ad 2 responsive -->
			<ins class="adsbygoogle"
			style="display:block"
			data-ad-client="ca-pub-8408941960924322"
			data-ad-slot="4137016599"
			data-ad-format="auto"
			data-full-width-responsive="true"></ins>
			<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
			</script>
		</div>	
		<!--<div class="states">		-->
			<!--</div>-->
	</div>
	</div>
</section>

<section id="courses-section" class="popular-courses-area ">
	<div class="container">
		<div class="row justify-content-md-center">
			<div class="col-lg-12">
				<div class="text-center">
					<h2 class="text-capitalize section-heading" style="margin-bottom: 30px"><?php if($scholarshipsCategory=='Scholarship'){
					 echo 'Abroad';
					}else{
					    echo 'Scholarship';
					}
					?>
					    </h2>
				</div>
				<!--/.section-heading-area--> 
			</div>
			<!--/.col-lg-8-->
		</div>
		<div class="row">
			<?php $index= 1;$node=1; foreach($other_scholarships as $other):
			if($node == 1){
			        $node+=2;
			    }?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12">
				<a href="<?php echo base_url('scholarships-details/'.$other->scholarship_id)?>">
				<div class="card card-height" style="height:120px !important">
					<div class="row" style="padding-top:20px !important;padding-left:12px">
						<div class="col-3">
							<div style="background-color: #ff7f45; border-radius: 5px ; padding:12px;color:#fff; height:78px !important; width:75px !important" align="center">
							<h5 style="color:#fff"><?php $str= $other->application_end_date;
							$newdata = date("d", strtotime($str));
							echo $newdata; 
							
						?></h5>
						<h5 style="color:#fff"><?php $str= $other->application_end_date;
							$month =date("F", strtotime($str));
							$result = substr($month, 0, 3);
							echo $result;
						?></h5>
							<p style="font-size:10px;padding-bottom:2px">Last Date</p>
					</div>
						</div>
						<div class="col-9">
						    <div style="padding-top:10px !important">
							<h6 class="addReadMore showlesscontent">
						    								<?php echo $other->scholarship_name;?>
						</h6>
						</div>
						</div>
					</div>
					
				
				
				
				</div>
			</a>
			</div>
			<?php if($index == $node){?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12 mobile-ad" style="display:none" align="center">
			<ins class="adsbygoogle"
     style="display:inline-block;width:270px;height:100px !important"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="9960188913"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
			</div>
		
			<?php $node+=3;}?>
			<?php  $index++;  endforeach; ?>
		</div>	

	

					</div>

					<div class="addbox">
						<div class="Add1" >
							<!-- screen 2 - Ad 3 responsive -->
							<ins class="adsbygoogle"
							style="display:block"
							data-ad-client="ca-pub-8408941960924322"
							data-ad-slot="1866076472"
							data-ad-format="auto"
							data-full-width-responsive="true"></ins>
							<script>
								(adsbygoogle = window.adsbygoogle || []).push({});
							</script>
						</div>
					</div>	

				</section>

				<style>
					@media (min-width: 1200px) {
						.container {
							max-width: 1400px;
						}
					}
					.container{

						margin-left: 0;

					}
					.card-height{
					   height:280px !important; 
					}
					.card-header{
					    max-height:35px; 
					    margin-bottom:30px
					}
					 @media only screen and (max-width: 600px) {
					   .card-height{
					      height:auto !important;  
					   }
					   
					 }
					 @media screen and (max-width: 650px) {
                        .card-height {
                        height:auto !important;  
					   }
					   
					 }
				</style>
				<style>
    .addReadMore.showlesscontent .SecSec,
    .addReadMore.showlesscontent .readLess {
        display: none;
    }

    .addReadMore.showmorecontent .readMore {
        display: none;
    }

    .addReadMore .readMore,
    .addReadMore .readLess {
        font-weight: bold;
        margin-left: 2px;
        font-size:12px;
        color: #337ab7;
        cursor: pointer;
    }

    .addReadMoreWrapTxt.showmorecontent .SecSec,
    .addReadMoreWrapTxt.showmorecontent .readLess {
        display: block;
    }
    .SecSec{
        font-size:15px;
    }
    </style>
				<script>

function AddReadMore() {
    //This limit you can set after how much characters you want to show Read More.
    var carLmt = 72;
    // Text to show when text is collapsed
    // var readMoreTxt = " ... Know More";
    // Text to show when text is expanded
    // var readLessTxt = " Know Less";


    //Traverse all selectors with this class and manupulate HTML part to show Read More
    $(".addReadMore").each(function() {
        if ($(this).find(".firstSec").length)
            return;

        var allstr = $(this).text();
        if (allstr.length > carLmt) {
            var firstSet = allstr.substring(0, carLmt);
            var secdHalf = allstr.substring(carLmt, allstr.length);
            var strtoadd = firstSet + "<span class='SecSec'>" + secdHalf + "</span><span class='readMore'  title='Click to Show More'>" + readMoreTxt + "</span><span class='readLess' title='Click to Show Less'>" + readLessTxt + "</span>";
            $(this).html(strtoadd);
        }

    });
    //Read More and Read Less Click Event binding
    $(document).on("click", ".readMore,.readLess", function() {
        $(this).closest(".addReadMore").toggleClass("showlesscontent showmorecontent");
    });
}
$(function() {
    //Calling function after Page Load
    AddReadMore();
});

</script>
	
