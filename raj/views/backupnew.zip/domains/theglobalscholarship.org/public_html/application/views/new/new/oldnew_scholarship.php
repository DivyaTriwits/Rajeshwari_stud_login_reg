<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
crossorigin="anonymous"></script>

<section id="courses-section" class="popular-courses-area " >
	<div class="container" >
		<div class="row justify-content-md-center">
			<div class="col-lg-12">
				<div class="text-center">
					<h1 class="text-capitalize section-heading" style="margin-bottom: 30px"><?php 
					$scholarshipsCategory = str_replace('%20', ' ', $this->uri->segment(2));
					echo $scholarshipsCategory?> Scholarship</h1>
				</div>
				<!--/.section-heading-area--> 
			</div>
			<!--/.col-lg-8-->
		</div>
		<div class="Addbox text-center mobile-card" style="height: 150px; margin: 10px 0px;">
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout-key="-f9+6h-a-d6+og"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="9489872475"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
		<div class="row">
			<?php $index =1; $node=1; foreach($scholarships as $value): 
			    
			    if($node == 1){
			        $node+=2;
			    }
			    
			?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12">
				<div class="card card-height" style="">
					<div class="card-header custom-card-header border-bottom-0 " style="">
						<h4 class="main-content-label tx-dark tx-medium mb-0 font addReadMore showlesscontent">
						    								<?php echo $value->scholarship_name;?>
						</h4>
					</div>
					<div class="card-body card-content" > 
						<h6 class="card-h6-content">
							<div class="media-icon-card icon-margin bg-primary-transparent text-primary" style="font-size:12px;margin-right:4px"> <i class="ti-calendar" style="color:green"></i>
							</div>
							
							<?php $str= $value->application_start_date;
							
							echo date("d-m-Y", strtotime($str)); ?>
						</h6>
						<h6 class="card-h6-content" >
							<div class="media-icon-card icon-margin bg-primary-transparent text-danger"  style="font-size:12px;margin-right:4px"> <i class="ti-calendar" ></i>
							</div>
						 <?php $str= $value->application_end_date;
							
							echo date("d-m-Y", strtotime($str)); ?>
						
						</h6>
						<h6 class="card-h6-content">
							<div class="media-icon-card icon-margin bg-primary-transparent text-primary"  style="font-size:12px;margin-right:4px"> <i class="fa fa-rupee" ></i>
							</div>
							<?$amount = $value->scholarship_worth;
                               setlocale(LC_MONETARY, 'en_IN');
                                $amount = money_format('%!i', $amount);
                                    echo $amount;?>
							
						</h6>
							<h6 class="card-h6-content">
							<div class="media-icon-card icon-margin bg-primary-transparent text-primary"  style="font-size:12px;margin-right:4px"> <i class="fa fa-graduation-cap" ></i>
							</div>
					        <!--<?php echo $value->courses?>-->
							 <?php $course = json_decode($value->courses); 
							 echo $course[0]?>
						</h6>
					</div>
					<div class="card-footer">
						<a href="<?php echo base_url('scholarships-details/'.$value->scholarship_id)?>" class="btn btn-primary ripple btn-block">View</a>
					</div>
				</div>
			</div>
			
			<?php if($index == $node){?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12 mobile-ad" style="display:none">
			<ins class="adsbygoogle"
                 style="display:block"
                 data-ad-format="fluid"
                 data-ad-layout-key="-fb+5w+4e-db+86"
                 data-ad-client="ca-pub-8408941960924322"
                 data-ad-slot="5199115548"></ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
			</div>
			<?php $node+=3;}?>
			<?php $index++; endforeach; ?>
		</div>

	</div>	
	<style>
	@media (max-width : 480px){
	    .mobile-ad{
	     display:block !important;  
	     width:auto;
	     height:150px;
	    }
	}
	    
	</style>
	<div  class="addbox" id="fadd">
		<div class="Add" style="height:300px !important">
			<!-- screen 2 - Ad 2 responsive -->
			<ins class="adsbygoogle"
			style="display:block"
			data-ad-client="ca-pub-8408941960924322"
			data-ad-slot="4137016599"
			data-ad-format="auto"
			data-full-width-responsive="true"></ins>
			<script>
				(adsbygoogle = window.adsbygoogle || []).push({});
			</script>
		</div>	
		<!--<div class="states">		-->
			<!--</div>-->
	</div>
</section>

<section id="courses-section" class="popular-courses-area ">
	<div class="container">
		<div class="row justify-content-md-center">
			<div class="col-lg-12">
				<div class="text-center">
					<h2 class="text-capitalize section-heading" style="margin-bottom: 30px">Some Other Scholarship</h2>
				</div>
				<!--/.section-heading-area--> 
			</div>
			<!--/.col-lg-8-->
		</div>
		<div class="row">
			<?php $index= 1; foreach($other_scholarships as $other):?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12">
				<div class="card card-height">
					<div class="card-header custom-card-header border-bottom-0 " >
						<h4 class="main-content-label tx-dark tx-medium mb-0 font addReadMore showlesscontent">
						    								<?php echo $other->scholarship_name;?>
						</h4>
						
					
					</div>
						<div class="card-body card-content" > 
						<h6 class="card-h6-content">
							<div class="media-icon-card icon-margin bg-primary-transparent text-primary" style="font-size:12px;margin-right:4px"> <i class="ti-calendar" style="color:green"></i>
							</div>
							<?php $str= $other->application_start_date;
							
							echo date("d-m-Y", strtotime($str)); ?>
						
						</h6>
						<h6 class="card-h6-content" >
							<div class="media-icon-card icon-margin bg-primary-transparent text-danger"  style="font-size:12px;margin-right:4px"> <i class="ti-calendar" ></i>
							</div>
								<?php $str= $other->application_end_date;
							
							echo date("d-m-Y", strtotime($str)); ?>
						
						</h6>
						<h6 class="card-h6-content">
							<div class="media-icon-card icon-margin bg-primary-transparent text-primary"  style="font-size:12px;margin-right:4px"> <i class="fa fa-rupee" ></i>
							</div>
							<?$amount = $other->scholarship_worth;
                               setlocale(LC_MONETARY, 'en_IN');
                                $amount = money_format('%!i', $amount);
                                    echo $amount;?>
							
						</h6>
							<h6 class="card-h6-content">
							<div class="media-icon-card icon-margin bg-primary-transparent text-primary"  style="font-size:12px;margin-right:4px"> <i class="fa fa-graduation-cap" ></i>
							</div>
					        <!--<?php echo $value->courses?>-->
							 <?php $course = json_decode($other->courses); 
							 echo $course[0]?>
						</h6>
					</div>
				
					<div class="card-footer">
						<a href="<?php echo base_url('scholarships-details/'.$other->scholarship_id)?>" class="btn btn-primary ripple btn-block">View</a>
					</div>
				</div>
			</div>
			<?php  $index++;  endforeach; ?>
		</div>	

	

					</div>

					<div class="addbox">
						<div class="Add1" >
							<!-- screen 2 - Ad 3 responsive -->
							<ins class="adsbygoogle"
							style="display:block"
							data-ad-client="ca-pub-8408941960924322"
							data-ad-slot="1866076472"
							data-ad-format="auto"
							data-full-width-responsive="true"></ins>
							<script>
								(adsbygoogle = window.adsbygoogle || []).push({});
							</script>
						</div>
					</div>	

				</section>

				<style>
					@media (min-width: 1200px) {
						.container {
							max-width: 1400px;
						}
					}
					.container{

						margin-left: 0;

					}
					.card-height{
					   height:280px !important; 
					}
					.card-header{
					    max-height:35px; 
					    margin-bottom:30px
					}
					 @media only screen and (max-width: 600px) {
					   .card-height{
					      height:auto !important;  
					   }
					   
					 }
					 @media screen and (max-width: 650px) {
                        .card-height {
                        height:auto !important;  
					   }
					   
					 }
				</style>
				<style>
    .addReadMore.showlesscontent .SecSec,
    .addReadMore.showlesscontent .readLess {
        display: none;
    }

    .addReadMore.showmorecontent .readMore {
        display: none;
    }

    .addReadMore .readMore,
    .addReadMore .readLess {
        font-weight: bold;
        margin-left: 2px;
        font-size:12px;
        color: #337ab7;
        cursor: pointer;
    }

    .addReadMoreWrapTxt.showmorecontent .SecSec,
    .addReadMoreWrapTxt.showmorecontent .readLess {
        display: block;
    }
    .SecSec{
        font-size:15px;
    }
    </style>
				<script>

function AddReadMore() {
    //This limit you can set after how much characters you want to show Read More.
    var carLmt = 72;
    // Text to show when text is collapsed
    var readMoreTxt = " ... Know More";
    // Text to show when text is expanded
    var readLessTxt = " Know Less";


    //Traverse all selectors with this class and manupulate HTML part to show Read More
    $(".addReadMore").each(function() {
        if ($(this).find(".firstSec").length)
            return;

        var allstr = $(this).text();
        if (allstr.length > carLmt) {
            var firstSet = allstr.substring(0, carLmt);
            var secdHalf = allstr.substring(carLmt, allstr.length);
            var strtoadd = firstSet + "<span class='SecSec'>" + secdHalf + "</span><span class='readMore'  title='Click to Show More'>" + readMoreTxt + "</span><span class='readLess' title='Click to Show Less'>" + readLessTxt + "</span>";
            $(this).html(strtoadd);
        }

    });
    //Read More and Read Less Click Event binding
    $(document).on("click", ".readMore,.readLess", function() {
        $(this).closest(".addReadMore").toggleClass("showlesscontent showmorecontent");
    });
}
$(function() {
    //Calling function after Page Load
    AddReadMore();
});

</script>
	
