
<div class="Addbox text-center" style="margin: 10px 0px; padding-top:45px !important;">
   <!-- Screen 3 - Ad 2 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="4868051162"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>

<section id="courses-section" class="popular-courses-area" style=" display: flex;">
    <?php if($details->scholarship_type == 'Internship'){
    $mainname="Internship";}else{
    $mainname="Scholarship";}?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-xl-6 col-md-12 col-12 col-sm-12">
				<div class="card" style="margin-bottom:10px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font"  style="letter-spacing: 0; text-transform:capitalize;"><?php echo $mainname; ?> Details</h5>
					</div>
					<div class="card-body">

						<div class="media">
							<div class="media-icon bg-primary-transparent text-primary" > <i class="ti-write"></i> </div>
							<div class="media-body">
								<span class="tx-dark" style="color: black;padding-left: 10px"><?php echo $mainname; ?> Name</span>
								<div style="padding-left: 10px;color:#ff7f45"><!-- <?php if($getScholarship!=''){echo $getScholarship->scholarship_name;}?> -->
									<?php echo $details->scholarship_name;?>
								</div>
							</div>
						</div>
						<?php if($getScholarship!=''){?>
						<div class="media">
							<div class="media-icon bg-success-transparent text-primary"> <i class="fa fa-handshake-o" ></i> </div>
							<div class="media-body">
								<strong> <span style="color: black; padding-left: 10px"><?php echo $mainname; ?> Provider</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45"> <!-- <?php if($getScholarship!=''){echo $getScholarship->scholarship_provider;}?> -->
									<?php echo $details->scholarship_provider;?>
								</div>		
							</div>
						</div>
							<?php }?>
						<div class="media">
							<div class="media-icon bg-success-transparent text-primary"> <i class="fa fa-rupee" ></i> </div>
							<div class="media-body">
								<strong> <span style="color: black; padding-left: 10px"><?php echo $mainname; ?> Benefits</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45"><!-- <?php if($getScholarship!=''){echo $getScholarship->benefits;}?> -->
									<!--<?php echo $details->scholarship_worth;?>-->
									<?php $amount = $details->scholarship_worth;
									$newamount= number_format($details->scholarship_worth, 1, ".", "") + 0;
                               setlocale(LC_MONETARY, 'en_IN');
                                $amount = money_format('%.0n', $newamount);
                                
                                    echo $amount;
                                    ?>
								</div>
							</div>
						</div>
						
						<div class="media">
							<div class="media-icon bg-success-transparent text-primary"> <i class="fa fa-rupee" ></i> </div>
							<div class="media-body">
								<strong> <span style="color: black; padding-left: 10px">Family Income</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45"> 
									<!-- <?php if($getScholarship->family_annual_income  != 0 )
									{echo $getScholarship->family_annual_income;}
									else{ echo 'Not mentioned'; }?> -->
									<!--<?php echo $details->family_annual_income;?>-->
									<?$amount = $details->family_annual_income;
										$newamount= number_format($details->family_annual_income, 1, ".", "") + 0;
                               setlocale(LC_MONETARY, 'en_IN');
                                $amount = money_format('%.0n', $newamount);
                                    echo $amount;?>
								</div>		
							</div>
						</div>
					
					</div>
				</div>
			</div>
         
			<div class="col-lg-12 col-xl-6 col-md-12 col-12 col-sm-12" >
				
				<div class="card" style="margin-bottom:10px" >
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">Education</h5>
					</div>
					<div class="card-body" style="padding-top:8px !important">

						<div class="media">
							<!--<div class="media-icon bg-primary-transparent text-primary"> <i class="ion-calendar" ></i> </div>-->
							<div class="media-body"> 
							<!--<strong> <span style="color: black; padding-left: 10px">Start Date</span></strong> -->
								<div class="addReadMore showlesscontent" style="padding-left: 10px;color:#ff7f45;" >
							
							   <?php 
							   if($details->current_class_or_degree == 'null' || empty($details->current_class_or_degree)){
							     $couses=   $details->courses;
							   }else{
							      
							        $couses=   $details->current_class_or_degree;
							   }
							   
							    $course = json_decode($couses);
							   foreach($course as $course){?>
                                                   <a class="educationarray" ><?php echo $course ; ?>,</a>  
                                                   
                                                    <?php }?>
                                                    <div class="show-more">Show more</div>
								</div>
							</div>
						</div>
					
					</div>
				</div>
			</div>
		
		</div>		
	</div>
</section>

<div class="Addbox text-center" style="margin: 10px 0px;">
   <!-- Screen 3 - Ad 2 -->
<!--<ins class="adsbygoogle"-->
<!--     style="display:block"-->
<!--     data-ad-format="fluid"-->
<!--     data-ad-layout-key="-ef+6k-30-ac+ty"-->
<!--     data-ad-client="ca-pub-8408941960924322"-->
<!--     data-ad-slot="6101225875"></ins>-->
<!--<script>-->
<!--     (adsbygoogle = window.adsbygoogle || []).push({});-->
<!--</script>-->
<ins class="adsbygoogle"
     style="display:inline-block;width:301px;height:157px !important"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="9960188913"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<section id="courses-section" class="popular-courses-area" style=" display: flex;">
	<div class="container">
		<div class="row">
		    
			<div class="col-lg-6 col-xl-12 col-md-12 col-12 col-sm-12">
				<div  style="margin-bottom:10px;margin-left: -20px !important">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font"><?php echo $mainname; ?> Description</h5>
					</div>
					<div class="card-body">	
						<ul class="unorderd">
							
							<li><?php echo $details->scholarship_description;?></li>
							
							</ul>
		                     <div>				
<!--<ins class="adsbygoogle"-->
<!--     style="display:block"-->
<!--     data-ad-format="fluid"-->
<!--     data-ad-layout-key="-ef+6k-30-ac+ty"-->
<!--     data-ad-client="ca-pub-8408941960924322"-->
<!--     data-ad-slot="6101225875"></ins>-->
<!--<script>-->
<!--     (adsbygoogle = window.adsbygoogle || []).push({});-->
<!--</script>-->
	<ins class="adsbygoogle"
     style="display:inline-block;width:280px;height:100px !important"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="9960188913"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
							<a href="<?php echo base_url('more-scholarships-details/'.$this->uri->segment(2))?>" style="color: #ff7f45;">Read more about this <?php echo $mainname; ?>...</a>	
							</br>
								<a href="https://t.me/theglobalscholarship" style="color: blue;">Join telegram channel.!</a>	
					</div>
				</div>
			</div>
			
			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12 text-center">
        	    <!-- Screen 3 - Ad 3 -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-8408941960924322"
             data-ad-slot="1491506109"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
        </div>
				
			
			<!--<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12" id="mobilecard">-->
			<!--	<div class="card" style="margin-bottom:10px">-->
			<!--		<div class="card-header custom-card-header border-bottom-0 ">-->
			<!--			<h5 class="main-content-label tx-dark tx-medium mb-0 font">How To Apply</h5>-->
			<!--		</div>-->
			<!--		<div class="card-body">	-->
			<!--		<?php if($details->how_apply != ''){?>-->
			<!--		<li><?php echo $details->how_apply;?></li>-->
					
			<!--		<?php } else {?>-->
			<!--		<h6>Steps to be followed:</h6>-->
			<!--			<li>1. Login your Account https://www.theglobalscholarship.org/student-login</li>-->
   <!--                  	<li> 2. Go to Notified Scholarships tab</li>-->
   <!--               	<li>3. For Detailed apply process visit: https://www.youtube.com/c/TheGlobalScholarshiporg</li>-->
			<!--		<?php }?>-->
									
			<!--		</div>-->
			<!--	</div>-->
			<!--</div>-->
			
		</div>
	</div>
	<div class="addbox">
	<div class="add" style="background-color: #ff7f45; height: 470px; width: 300px; background-image: url('assets/images/add/ads-logo.png');  background-size: 100% 100%;">
	    <!-- Screen 3 - Ad 4 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="4261139671"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
	</div>
	</div>
</section>

<section id="courses-section" class="popular-courses-area ">
	<div class="container">
		<div class="row justify-content-md-center">
			<div class="col-lg-12">
				<div class="text-center">
					<h2 class="text-capitalize section-heading" style="margin-bottom: 30px">Other Scholarship</h2>
				</div>
				<!--/.section-heading-area--> 
			</div>
			<!--/.col-lg-8-->
		</div>
		<div class="row">
			<?php $index= 1; foreach($some as $other):?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12">
				<a href="<?php echo base_url('scholarships-details/'.$other->scholarship_id)?>">
				<div class="card card-height"  style="height:120px !important">
					<div class="row" style="padding-top:12px;padding-bottom: 10px;padding-left:12px">
						<div class="col-3">
						<div style="background-color: #ff7f45; border-radius: 5px ; padding:12px;color:#fff; height:75px !important; width:75px !important" align="center">
							<h6><?php $str= $other->application_end_date;
							$newdata = date("d", strtotime($str));
							echo $newdata; 
							
						?></h6>
						<h6><?php $str= $other->application_end_date;
							$month =date("F", strtotime($str));
							$result = substr($month, 0, 3);
							echo $result;
						?></h6>
						<p style="font-size:10px;padding-bottom:2px">Last Date</p>
					</div>
						</div>
						<div class="col-9">
						    <div style="padding-top:10px !important">
							<h6 class="addReadMore showlesscontent">
						    								<?php echo $other->scholarship_name;?>
						</h6>
						</div>
						</div>
					</div>
					
				
					
				</div>
			</a>
			</div>
			<?php  $index++;  endforeach; ?>
		</div>	

	

					</div>

					

				</section>

<!--<section id="courses-section" class="popular-courses-area ">-->
<!--	<div class="container">-->
<!--		<div class="row">-->
<!--			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12">-->
<!--				<div class="card" style="margin-bottom:10px">-->
<!--					<div class="card-header custom-card-header border-bottom-0 ">-->
<!--						<h5 class="main-content-label tx-dark tx-medium mb-0 font">How To Apply</h5>-->
<!--					</div>-->
<!--					<div class="card-body">	-->
						<!-- <ul class="unorderd">
<!--							<li>The Scheme "Begum Hazrat Mahal National Scholarship" for Girl Students belonging to the Minority Communities was earlier known as "Maulana Azad National Scholarship" Scheme. It was started by the Foundation in the academic year 2003-04. The main purpose of the scheme is to provide financial assistance to meritorious girl students belonging to national minorities, who cannot continue their education due to lack of financial support. Please go through the attachment Criteria:</li>-->
							
<!--								<li>Only girl students belonging to six notified Minority Communities i.e. Muslims, Christians, Sikhs, Buddhists, Jains, and Parsis are eligible.</li>-->
<!--								<li>Scholarship will be awarded to minorities’ girl students who are studying in Class 9th to 12th, and have secured at least 50% marks or equivalent grade in aggregate in the previous class/qualifying exam.</li>-->
<!--								<li>Annual income of the student’s parent/guardian from all sources does not exceed Rs.2.00 lakh.</li>-->
<!--								<li>Annual income of the student’s parent/guardian from all sources does not exceed Rs.2.00 lakh.</li>-->
<!--								<li>Candidates can contact the Help Desk for resolution of the technical problems on-->
<!--									<ul>-->
<!--									<li>011-23583788/89</li>-->
<!--									<li>scholarship-maef@nic.in</li>-->
<!--									<li>scholarshipmaef@gmail.com</li>-->
<!--									</ul>-->

<!--								</li>-->
<!--							</ul>	 -->
<!--					</div>-->
<!--				</div>-->
<!--			</div>-->
<!--		</div>-->
<!--	</div>	-->
<!--</section>-->


	<div class="Addbox text-center"  style="margin: 10px 0px;">
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="4868051162"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
	</div>
	
	

	<!-- <section id="courses-section" class="popular-courses-area ">
	<div class="displayButton" >
	    <?php $sid=$details->scholarship_link;
	    $url = urlencode($sid);
	   
	    ?>
	     <?php if($this->session->userdata('student_username')){ 
                        ?>
                        <a target=_blank class="btn registerbutton"  href="<?php echo $sid?>" style="text-transform: capitalize;">
	Click Here To Apply
	</a>
                        <?php }else{?>
	<a  class="btn registerbutton"  href="<?php echo base_url();?>student-login?sid=<?php echo $url?>" style="text-transform: capitalize;">
	Login & Apply
	</a>
	  <?php }?>
		<div class="watchLink"><Strong>Watch Complete process </Strong><a class="youtubelink" href="#" style="color: blue;text-decoration: underline;">here.!</a>
		</div>		
	</div>
</section> -->


	<style>
		@media (min-width: 1200px) {
			.container {
				max-width: 1400px;
			}
			.container{
		
			}
			#mobilecard{
				display: block;
			}
		</style>
		<style>
		@media (max-width: 600px) {
			
			#mobilecard{
				display: none !important;
			}
		</style>
		<style>
			.unorderd li{
				color: black;
				list-style-type: initial;
				margin-bottom: 5px;
				
			}
		</style>
			<style>
    .addReadMore.showlesscontent .SecSec,
    .addReadMore.showlesscontent .readLess {
        display: none;
    }

    .addReadMore.showmorecontent .readMore {
        display: none;
    }

    .addReadMore .readMore,
    .addReadMore .readLess {
        font-weight: bold;
        margin-left: 2px;
        font-size:12px;
        color: #337ab7;
        cursor: pointer;
    }

    .addReadMoreWrapTxt.showmorecontent .SecSec,
    .addReadMoreWrapTxt.showmorecontent .readLess {
        display: block;
    }
    .SecSec{
        font-size:15px;
    }
    .educationarray{
        font-size:13px !important;
    }
    .show-more {
  display: none;
  cursor: pointer;
  color:#337ab7;
  font-size:12px;
}
    </style>
						<script>

function AddReadMore() {
    if ($('.educationarray').length > 3) {
  $('.educationarray:gt(2)').hide();
  $('.show-more').show();
   var readMoreTxt = " ... Know More";
    // Text to show when text is expanded
    var readLessTxt = " Know Less";
}
   
}
$('.show-more').on('click', function() {
  //toggle elements with class .ty-compact-list that their index is bigger than 2
  $('.educationarray:gt(2)').toggle();
  //change text of show more element just for demonstration purposes to this demo
  $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
});
$(function() {
    //Calling function after Page Load
    AddReadMore();
});

</script>