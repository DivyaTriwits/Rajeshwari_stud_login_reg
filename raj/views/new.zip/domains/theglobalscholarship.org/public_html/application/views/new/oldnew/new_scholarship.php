<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
     crossorigin="anonymous"></script>
<section id="courses-section" class="popular-courses-area ">
	<div class="container">
		<div class="row justify-content-md-center">
			<div class="col-lg-12">
				<div>
					<h2 class="text-capitalize" style="margin-bottom: 30px"><?php 
                    $scholarshipsCategory = str_replace('%20', ' ', $this->uri->segment(2));
					echo $scholarshipsCategory?></h2>
				</div>
				<!--/.section-heading-area--> 
			</div>
			<!--/.col-lg-8-->
		</div>
		<div class="row">
		 <?php $index =1; foreach($scholarships as $value): ?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12">
				<div class="card" style="height: 264px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0" style="letter-spacing: 0; font-size: 15px; text-transform:capitalize;">
							<?php echo $value->scholarship_name; ?></h5>
					</div>
					<div class="card-body">
						<h6 class="" style="margin-bottom: 0.5rem;">Start Date : <?php echo $value->application_start_date; ?></h6>
						<h6 class="" style="margin-bottom: 0.5rem;">End Date : <?php echo $value->application_end_date; ?></h6>
						<h6 class="" style="margin-bottom: 0.5rem;">Benefits : <?php echo $value->scholarship_worth; ?></h6>
						
					</div>
					<div class="card-footer">
						<a href="<?php echo base_url('scholarships-details/'.$value->scholarship_id)?>" class="btn btn-primary ripple btn-block">View</a>
					</div>
				</div>
			</div>
			
			<?php if($index == 6) {?>
			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12 text-center d-sm-block " style="height:100px !important;">
			    <!-- Screen 2 - Ad 6 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="9960188913"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
			</div>
			<?php }?>
			
			
			<?php $index++; endforeach; ?>
			
		</div>
		
	</div>	
	<div class="addbox" id="fadd">
		<div class="Add">
		  
		  
		  
		  
<!-- screen 2 - Ad 2 responsive -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="4137016599"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
		  
		  
		  
		  	
		</div>	
		<!--<div class="states">		-->
		<!--</div>-->
	</div>
</section>

<section id="courses-section" class="popular-courses-area ">
	<div class="container">
		<div class="row justify-content-md-center">
			<div class="col-lg-12">
				<div>
					<h2 class="text-capitalize" style="margin-bottom: 30px">Some Other Scholarship</h2>
				</div>
				<!--/.section-heading-area--> 
			</div>
			<!--/.col-lg-8-->
		</div>
		<div class="row">
			<?php $index= 1; foreach($other_scholarships as $other):?>
			<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12">
				<div class="card" style="height: 264px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0" style="letter-spacing: 0; font-size: 15px; text-transform:capitalize;">
							<?php echo $other->scholarship_name; ?></h5>
					</div>
					<div class="card-body">
						<h6 class="" style="margin-bottom: 0.5rem;">Start Date : <?php echo $other->application_start_date; ?></h6>
						<h6 class="" style="margin-bottom: 0.5rem;">End Date : <?php echo $other->application_end_date; ?></h6>
						<h6 class="" style="margin-bottom: 0.5rem;">Benefits : <?php echo $other->scholarship_worth; ?></h6>
						
					</div>
					<div class="card-footer">
						<a href="<?php echo base_url('scholarships-details/'.$other->scholarship_id)?>" class="btn btn-primary ripple btn-block">View</a>
					</div>
				</div>
			</div>
			<?php if($index == 6) {?>
			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12">
			    <!-- Screen 2 - Ad 5 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="9452265917"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
			</div>
			<?php }?>
			
			<?php  $index++;  endforeach; ?>
		</div>		
	</div>
	
	<div class="addbox">
		<div class="Add1" >
		    
		    <!-- screen 2 - Ad 3 responsive -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="1866076472"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

		</div>

	</div>	

</section>

<style>
	@media (min-width: 1200px) {
		.container {
			max-width: 1400px;
		}
	}
	.container{
		
		margin-left: 0;
		
	}
</style>
