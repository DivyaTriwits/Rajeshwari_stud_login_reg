<div class="Addbox text-center" style="height: 150px; margin: 10px 0px;">
   <!-- Screen 3 - Ad 2 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="1930489805"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<section id="courses-section" class="popular-courses-area" style=" display: flex;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-xl-6 col-md-12 col-12 col-sm-12">
				<div class="card" style="margin-bottom:10px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font"  style="letter-spacing: 0; text-transform:capitalize;">Scholarship Details</h5>
					</div>
					<div class="card-body">

						<div class="media">
							<div class="media-icon bg-primary-transparent text-primary" > <i class="ti-write"></i> </div>
							<div class="media-body">
								<span class="tx-dark" style="color: black;padding-left: 10px">Scholarship Name</span>
								<div style="padding-left: 10px;color:#ff7f45">
									<?php echo $details->scholarship_name;?>
								</div>
							</div>
						</div>
						<div class="media">
							<div class="media-icon bg-success-transparent text-primary"> <i class="fa fa-handshake-o" ></i> </div>
							<div class="media-body">
								<strong> <span style="color: black; padding-left: 10px">Scholarship Provider</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45"> 
									<?php echo $details->scholarship_provider;?>
								</div>		
							</div>
						</div>
						<div class="media">
							<div class="media-icon bg-success-transparent text-primary"> <i class="fa fa-rupee" ></i> </div>
							<div class="media-body">
								<strong> <span style="color: black; padding-left: 10px">Scholarship Benefits</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45">
									<?$amount = $details->scholarship_worth;
                               setlocale(LC_MONETARY, 'en_IN');
                                $amount = money_format('%!i', $amount);
                                    echo $amount;?>
								</div>
							</div>
						</div>
						
						<div class="media">
							<div class="media-icon bg-success-transparent text-primary"> <i class="fa fa-rupee" ></i> </div>
							<div class="media-body">
								<strong> <span style="color: black; padding-left: 10px">Family Income</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45"> 
									<?$amount = $details->family_annual_income;
                               setlocale(LC_MONETARY, 'en_IN');
                                $amount = money_format('%!i', $amount);
                                    echo $amount;?>
								</div>		
							</div>
						</div>
						
					</div>
				</div>
			</div>
           
			<div class="col-lg-12 col-xl-6 col-md-12 col-12 col-sm-12">
				<div class="card" style="margin-bottom:10px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">Important Dates</h5>
					</div>
					<div class="card-body">
                       <div class="row">
                           <div class="col-lg-6">
						<div class="media">
							<div class="media-icon bg-primary-transparent text-primary"> <i class="ion-calendar" style="color:green"></i> </div>
							<div class="media-body"> <strong> <span style="color: black; padding-left: 10px">Start Date</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45">
										<?php $str= $details->application_start_date;
							echo date("d-m-Y", strtotime($str)); ?>
						
								</div>
							</div>
						</div>
						</div>
						<div class="col-lg-6">
						<div class="media">
							<div class="media-icon bg-success-transparent text-danger"> <i class="ion-calendar" ></i> </div>
							<div class="media-body"> 
								<strong> <span style="color: black; padding-left: 10px">End Date</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45"> 
										<?php $str= $details->application_end_date;
						            	echo date("d-m-Y", strtotime($str)); ?>
								</div>
							</div>
						</div>
						</div>
						</div>
					</div>
				</div>
				<div class="card" style="margin-bottom:10px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">Education</h5>
					</div>
					<div class="card-body" style="padding-top:8px !important">

						<div class="media">
							<div class="media-body"> 
								<div class="addReadMore showlesscontent" style="padding-left: 10px;color:#ff7f45;" >
							
							   <?php 
							   if($details->current_class_or_degree == 'null' || empty($details->current_class_or_degree)){
							     $couses=   $details->courses;
							   }else{
							      
							        $couses=   $details->current_class_or_degree;
							   }
							   
							    $course = json_decode($couses);
							   foreach($course as $course){?>
                                                   <a class="educationarray" ><?php echo $course ; ?>,</a>  
                                                   
                                                    <?php }?>
                                                    <div class="show-more">Show more</div>
								</div>
							</div>
						</div>
					
					</div>
				</div>
			</div>
		</div>		
	</div>
</section>
<button>Join Telegram Channel</button>
<section id="courses-section" class="popular-courses-area " style="display: flex; ">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-xl-12 col-md-12 col-12 col-sm-12">
				<div class="card" style="margin-bottom:10px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">Scholarship Description</h5>
					</div>
					<div class="card-body">	
						<ul class="unorderd">
							
							<li><?php echo $details->scholarship_description;?></li>
							
							</ul>			
					</div>
				</div>
			</div>
			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12 text-center">
        	    <!-- Screen 3 - Ad 3 -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-8408941960924322"
             data-ad-slot="1491506109"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
        </div>
			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12">
				<div class="card" style="margin-bottom:10px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">Attachments</h5>
					</div>
					<div class="card-body">	
						<ul class="unorderd">
							<?php if($attachment->num_rows()>0){
                               foreach($attachment->result() as $files){
								?>
								 <?php if($files->attachment_file != ''){?>
							<li>
								Files : <a href="<?php echo base_url()?>download-file/<?php echo $attachment->attachment_file?>/<?php echo $attachment->scholarship_id?>" ><i class="fe fe-download" style="font-size:20px "></i></a>
							</li>
							<?php }?>
							<?php if($attachment->attachment_text != ''){?>
                               <li>Links : <a href="<?php echo $attachment->attachment_text?>"target="_blank">Click here</a>
                               	
                               </li>
								<?php }?>
							<?php }}?>
							
							</ul>


							<?php foreach ($getAttachments as $attachment) {?>
												<div class="d-lg-flex">
												    
												    <?php if($attachment->attachment_file != ''){?>
													<div class="mg-md-r-20 mg-b-10">
														<div class="main-profile-social-list">
															<div class="media">

																<div class="media-body"> <strong><span style="color: grey">Files</span> </strong>

																	<a href="<?php echo base_url()?>download-file/<?php echo $attachment->attachment_file?>/<?php echo $attachment->scholarship_id?>" ><i class="fe fe-download" style="font-size:20px "></i>
																	</a>
																</div>
															</div>
														</div>
													</div>
													<?php }else {?>
												<p>No Attachments</p>
                                                 <?php }?>
													<?php if($attachment->attachment_text != ''){?>
													<div class="mg-md-r-20 mg-b-10">
														<div class="main-profile-social-list">
															<div class="media">

																<div class="media-body"><strong> <span style="color: grey">Links</span></strong> <a href="<?php echo $attachment->attachment_text?>"target="_blank">Click here</a></div>
															</div>
														</div>
													</div>
													<?php } else {?>
												<p>No Attachments</p>
                                                 <?php }?>
												</div>
											<?php }?>					
					</div>
				</div>
			</div>	
			
			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12">
				<div class="card" style="margin-bottom:10px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">How To Apply</h5>
					</div>
					<div class="card-body">	
					<?php if($details->how_apply != ''){?>
					<li><?php echo $details->how_apply;?></li>
					
					<?php } else {?>
					<h6>Steps to be followed:</h6>
						<li>1. Login your Account https://www.theglobalscholarship.org/student-login</li>
                     	<li> 2. Go to Notified Scholarships tab</li>
                  	<li>3. For Detailed apply process visit: https://www.youtube.com/c/TheGlobalScholarshiporg</li>
					<?php }?>
										
					</div>
				</div>
			</div>
			
		</div>
	</div>
	<div class="addbox">
	<div class="add" style="background-color: #ff7f45; height: 470px; width: 300px; background-image: url('assets/images/add/ads-logo.png');  background-size: 100% 100%;">
	    <!-- Screen 3 - Ad 4 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="4261139671"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
	</div>
	</div>
</section>

	<div class="Addbox text-center">
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout-key="-f5+6e+9-cx+lz"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="1825977203"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
	</div>
	
	

	<section id="courses-section" class="popular-courses-area ">
	<div class="displayButton" >
	    <?php $sid=$details->scholarship_link;
	    $url = urlencode($sid);
	    ?>
	     <?php if($this->session->userdata('student_username')){ 
                        ?>
                        <a target=_blank class="btn registerbutton"  href="<?php echo $sid?>" style="text-transform: capitalize;">
	Click Here To Apply
	</a>
                        <?php }else{?>
	<a  class="btn registerbutton"  href="<?php echo base_url();?>student-login?sid=<?php echo $url?>" style="text-transform: capitalize;">
	Login & Apply
	</a>
	  <?php }?>
		<div class="watchLink"><Strong>Watch Complete process </Strong><a class="youtubelink" href="#" style="color: blue;text-decoration: underline;">here.!</a>
		</div>		
	</div>
</section>


	<style>
		@media (min-width: 1200px) {
			.container {
				max-width: 1400px;
			}
			.container{
		
			}
		</style>
		<style>
			.unorderd li{
				color: black;
				list-style-type: initial;
				margin-bottom: 5px;
				
			}
		</style>
			<style>
    .addReadMore.showlesscontent .SecSec,
    .addReadMore.showlesscontent .readLess {
        display: none;
    }

    .addReadMore.showmorecontent .readMore {
        display: none;
    }

    .addReadMore .readMore,
    .addReadMore .readLess {
        font-weight: bold;
        margin-left: 2px;
        font-size:12px;
        color: #337ab7;
        cursor: pointer;
    }

    .addReadMoreWrapTxt.showmorecontent .SecSec,
    .addReadMoreWrapTxt.showmorecontent .readLess {
        display: block;
    }
    .SecSec{
        font-size:15px;
    }
    .educationarray{
        font-size:13px !important;
    }
    .show-more {
  display: none;
  cursor: pointer;
  color:#337ab7;
  font-size:12px;
}
    </style>
						<script>

function AddReadMore() {
    if ($('.educationarray').length > 3) {
  $('.educationarray:gt(2)').hide();
  $('.show-more').show();
   var readMoreTxt = " ... Know More";
    // Text to show when text is expanded
    var readLessTxt = " Know Less";
}
   
}
$('.show-more').on('click', function() {
  //toggle elements with class .ty-compact-list that their index is bigger than 2
  $('.educationarray:gt(2)').toggle();
  //change text of show more element just for demonstration purposes to this demo
  $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
});
$(function() {
    //Calling function after Page Load
    AddReadMore();
});

</script>