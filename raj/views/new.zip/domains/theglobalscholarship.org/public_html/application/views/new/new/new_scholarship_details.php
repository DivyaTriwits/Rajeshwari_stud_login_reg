	<style>
      .desktopx{
	display:block;
	
}
.mobilex{
	display:none;
}
	
@media (max-width: 768px) {
	.desktopx{
	display:none;

}
.mobilex{
	display:block;
}
}
	@media (max-width : 480px){
	    .mobile-ad{
	     display:block !important;  
	     width:auto;
	     /*height:150px;*/
	    }
	    #telebutton{
    display:block !important;
}

#mobileButton{
   display:block !important; 
}
#deskButton{
    display:none !important;
}
.description{
    max-width: 347px; word-wrap: break-word;
}
#addcards{
    margin:0px 22px 0px 22px;
}
	}
		@media (min-width : 480px){
		#addcards{
    //margin:0px 52px 0px 52px;
}    
		}
	#telebutton{
    display:none;
}
	    .product-new {
    background: #fff;
        border-radius: 50%;
    color: #fff;
    font-size: 11px;
    font-weight: 600;
    height: 42px;
    right: 10px;
    line-height: 42px;
    position: absolute;
    text-align: center;
    text-shadow: 1px 2px 1px rgb(0 0 0 / 14%);
    top: 10px;
    width: 42px;
    z-index: 5;
}
.product-sale-off {
    background: red;
    border-radius: 0 12px 0;
    top: 0;
    color: #fff;
    font-size: 12px;
    font-weight: 500;
    height: 25px;
    line-height: 20px;
    position: absolute;
    right: 0;
    text-align: center;
    text-shadow: 1px 2px 1px rgb(0 0 0 / 14%);
    width: 100px;
    z-index: 5;
}
#deskButton{
    display:block !important;
}
#mobileButton{
   display:none !important; 
}
h1{
    color:#41044D;
}
h5{
    color:#000000;
}
.newregisterbutton{
   background: #41044D;
   border-color: #41044D;
   color:#F2B625;
}
	</style>
	<div style="background-color:#F2B625 !important">
	<div style="padding:52px 10px 20px 0px;">
	<h1 align="center"><?php echo $details->scholarship_name;?></h1>
	</div>
<div class=" text-center">
 
 <div class="desktopx">
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
     crossorigin="anonymous"></script>
<!-- New Ad Screen 3 Top(Desktop)
 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="1157052501"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>

<div class="mobilex">
  
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout-key="-6t+ed+2i-1n-4w"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="5389270542"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
</div>
<section id="courses-section" class="popular-courses-area" style=" display: flex;">
    <?php $mainname="Scholarship";?>
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-xl-6 col-md-12 col-12 col-sm-12">
				<div class="card" style="margin-bottom:10px">
				    <?php $Date = $details->scholarship_added_date;
				    $newDate = date("Y-m-d", strtotime($Date));  
				    $now = time(); // or your date as well
                     $your_date = strtotime($newDate);
                    $datediff = $now - $your_date;
                    $days= round($datediff / (60 * 60 * 24));
                    $otodaydate=date('Y-m-d');
                     $t=$details->application_end_date;
                    $exp= date("Y-m-d", strtotime($t));
                    $esort=strtotime($exp);
                    $expdiff =  $esort-$now;
                   // $exprydate=round($expdiff / (60 * 60 * 24));
                       $odate1 = new DateTime($t);
                     $odate2 = $odate1->diff(new DateTime($otodaydate));
                    
                     $exprydate= $odate2->days;
        //time difference in seconds for coundown timer
       
				    ?>
				    <?php if($days <= 4){?>
				    <span class="product-new"><img src="<?php echo base_url()?>website_assets/newtag.png"></span>
				    <?php }?>
					<div class="card-header custom-card-header border-bottom-0 ">
					    
						<h5 class="main-content-label tx-dark tx-medium mb-0 font"  style="letter-spacing: 0; text-transform:capitalize;"><?php echo $mainname; ?> Details</h5>
					</div>
					<div class="card-body">

						<div class="media">
							<div class="media-icon bg-primary-transparent text-primary" > <i class="fa fa-graduation-cap"></i> </div>
							<div class="media-body">
								<span class="tx-dark" style="color: black;padding-left: 10px"><?php echo $mainname; ?> Name</span>
								<div style="padding-left: 10px;color:#ff7f45">
									<?php echo $details->scholarship_name;?>
								</div>
							</div>
						</div>
						<div class="media">
							<div class="media-icon bg-success-transparent text-primary"> <i class="fa fa-handshake-o" ></i> </div>
							<div class="media-body">
								<strong> <span style="color: black; padding-left: 10px"><?php echo $mainname; ?> Provider</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45"> 
									<?php echo $details->scholarship_provider;?>
								</div>		
							</div>
						</div>
							<?php if($details->scholarship_worth != 0.00){?>
						<div class="media">
							<div class="media-icon bg-success-transparent text-primary"> <i class="fa fa-rupee" ></i> </div>
							<div class="media-body">
								<strong> <span style="color: black; padding-left: 10px"><?php echo $mainname; ?> Rewards</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45">
								
                                    	<?php $amount = $details->scholarship_worth+0;
                                 $new=(int)$details->scholarship_worth;
                               $newworthamout=$this->New_model->moneyFormatIndia($new);
                                   // echo number_format($amount);
                                   echo $newworthamout;
                                   ?>
								</div>
							</div>
						</div>
							<?php }?>
						<?php if($details->family_annual_income != 0.00){?>
						<div class="media">
							<div class="media-icon bg-success-transparent text-primary"> <i class="fa fa-rupee" ></i> </div>
							<div class="media-body">
								<strong> <span style="color: black; padding-left: 10px">Family Income</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45"> 
									
									
                                    	<?php $amount = $details->family_annual_income+0;
                               $new=(int)$details->family_annual_income;
                               $newamout=$this->New_model->moneyFormatIndia($new);
                                    
                                    echo $newamout;
                                    ?>
								</div>		
							</div>
						</div>
						<?php }?>
						<?php if($exprydate<=4 && $exprydate>0){?>
						<?php if($exprydate == 1){?>
						<span class="product-sale-off timer" id="<?php echo $value->scholarship_id?>"><?php echo $exprydate?> day to expire</span>
						<?php }else{?>
							<span class="product-sale-off timer" id="<?php echo $value->scholarship_id?>"><?php echo $exprydate?> days to expire</span>
							<?php }?>
						<?php }?>
					</div>
				</div>
			</div>
           
			<div class="col-lg-12 col-xl-6 col-md-12 col-12 col-sm-12">
				<div class="card" style="margin-bottom:10px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">Important Dates</h5>
					</div>
					<div class="card-body">
                       <div class="row">
                           <div class="col-lg-6">
						<div class="media">
							<div class="media-icon bg-primary-transparent text-primary"> <i class="ion-calendar" style="color:green"></i> </div>
							<div class="media-body"> <strong> <span style="color: black; padding-left: 10px">Start Date</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45">
							<?php $str= $details->application_start_date;
										$month =date("F", strtotime($str));
							$result = substr($month, 0, 3);
							echo date("d", strtotime($str)).' '.$result.' '.date("Y", strtotime($str)) ; ?>
								</div>
							</div>
						</div>
						</div>
						<div class="col-lg-6">
						<div class="media">
							<div class="media-icon bg-success-transparent text-danger"> <i class="ion-calendar" ></i> </div>
							<div class="media-body"> 
								<strong> <span style="color: black; padding-left: 10px">End Date</span></strong> 
								<div style="padding-left: 10px;color:#ff7f45"> 
						            	
						            		<?php $str= $details->application_end_date;
										$month =date("F", strtotime($str));
							$result = substr($month, 0, 3);
							echo date("d", strtotime($str)).' '.$result.' '.date("Y", strtotime($str)) ; ?>
								</div>
							</div>
						</div>
						</div>
						</div>
					</div>
				</div>
				<div class="text-center" style="display:none" >
 
                  </div>

				<div class="card" style="margin-bottom:10px">
					<div class="card-header custom-card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">Education</h5>
					</div>
					<div class="card-body" style="padding-top:8px !important">

						<div class="media">
							<div class="media-body"> 
								<div class="addReadMore showlesscontent" style="padding-left: 10px;color:#ff7f45;" >
							
							   <?php 
							   if($details->current_class_or_degree == 'null' || empty($details->current_class_or_degree)){
							     $couses=   $details->courses;
							   }else{
							      
							        $couses=   $details->current_class_or_degree;
							   }
							   
							    $course = json_decode($couses);
							   foreach($course as $course){?>
                                                   
                                                    <?php }?>
                                                          <a class="" ><?php
                                                          $str=$details->display_courses;
                                    $res = str_replace( array( '\'', '"', ';', '<', '>' ), ' ', $str);echo $res ; ?></a>
                                                  
								</div>
							</div>
						</div>
					
					</div>
				</div>
				
			</div>
		</div>		
	</div>
</section>
<div class="container" id="telebutton"><div class="col-lg-6 col-xl-12 col-md-12 col-12 col-sm-12" style="margin-bottom:10px;"><a href="https://t.me/theglobalscholarship"><button style="background-color:#2AABEE;color:#fff;border-radius:12px;padding:10px 10px 10px 10px"><i class="fa fa-telegram" style="font-size:32px;padding:2px 8px 2px 10px"></i><span style="font-size:20px;margin:15px !important ">Join Telegram Channel</span></button></a></div></div>
<div class=" text-center" >

</div>
<section id="courses-section" class="popular-courses-area " style="display: flex; ">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-xl-12 col-md-12 col-12 col-sm-12">
				<div class="" style="margin-bottom:10px;margin-left: -25px !important">
					<div class="card-header  border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font"><?php echo $mainname; ?> Description</h5>
					</div>
					<div class="card-body">	
						<ul class="unorderd description" >
							
							<li><?php echo $details->scholarship_description;?></li>
							
							</ul>			
					</div>
				</div>
			</div>
			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12 text-center">
        	    <!-- Screen 3 - Ad 3 -->
       <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="8793328936"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
        </div>
        <?php if($details->documents != ''){?>
			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12">
				<div class="" style="margin-bottom:10px;margin-left: -25px !important">
					<div class="card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">Attachments</h5>
					</div>
					<div class="card-body">	
						<ul class="unorderd">
						    <?php echo $details->documents?>
					</ul>					
					</div>
				</div>
			</div>	
			<?php }?>
			<div class="col-lg-12 col-xl-12 col-md-12 col-12 col-sm-12">
				<div class="" style="margin-bottom:10px;margin-left: -25px !important">
					<div class="card-header border-bottom-0 ">
						<h5 class="main-content-label tx-dark tx-medium mb-0 font">How To Apply</h5>
					</div>
					<div class="card-body">	
					<?php if($details->how_apply != ''){?>
					<!--<li><?php echo $details->how_apply;?></li>-->
					<ul class="unorderd">
						    <?php echo $details->how_apply?>
					</ul>
					<?php } else {?>
					<h6>Steps to be followed:</h6>
						<li>1. Login your Account https://www.theglobalscholarship.org/student-login</li>
                     	<li> 2. Go to Notified Scholarships tab</li>
                  	<li>3. For Detailed apply process visit: https://www.youtube.com/c/TheGlobalScholarshiporg</li>
					<?php }?>			
					</div>
				</div>
			</div>
			
		</div>
	</div>
	
</section>
<div class=" text-center">
 <div class="desktopx">
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
     crossorigin="anonymous"></script>
<!-- New Ad Screen 3 Bottom (Desktop)
 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="8900892727"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>

<div class="mobilex">
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
     crossorigin="anonymous"></script>
<!-- New Ad Screen 3 Bottom (Mobile) -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="9830831012"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div> 

</div>
	
	

	<section id="courses-section" class="popular-courses-area ">
	<div class="displayButton" >
	    <?php $sid=$details->scholarship_link;
	    $url = urlencode($sid);
	    //print_r($url);exit;
	    ?>
	     <?php if($this->session->userdata('student_username')){ 
                        ?>
                        <a target=_blank class="btn registerbutton"  href="<?php echo $sid?>" style="text-transform: capitalize;">
	Click Here To Apply
	</a>
                        <?php }else{?>
	<a target='_blank'  class="btn newregisterbutton"  href="<?php echo base_url();?>student-login?sid=<?php echo $url?>" style="text-transform: capitalize;">
	Login & Apply
	</a>
	  <?php }?>
		<div class="watchLink"><Strong>Watch Complete process </Strong><a class="youtubelink" target="_blank" href="<?php echo $details->vedio_link?>" style="color: blue;text-decoration: underline;">here.!</a>
		</div>
		<div style="padding-left:10px" >
		    <?php $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?>
		   <a target="_blank" href="whatsapp://send?text= <?php echo $details->scholarship_name;?> Scholarship , See More: <?php echo $actual_link;  ?>" data-action="share/whatsapp/share"  class="link-whatsapp"><button style="background-color:green;padding:4px;color:#fff;border-radius:10px"><i class="fa fa-whatsapp" aria-hidden="true" style="padding-right:6px"></i>Share via WhatsApp</button></a>
		</div>
	</div>

</section>

	</div>
	<style>
		@media (min-width: 1200px) {
			.container {
				max-width: 1400px;
			}
			.container{
		
			}
		</style>
		<style>
			.unorderd li{
				color: black;
				list-style-type: initial;
				margin-bottom: 5px;
				color:#000000 !important;
			}
			.unorderd{
			    	color:#000000 !important;
			}
		</style>
			<style>
    .addReadMore.showlesscontent .SecSec,
    .addReadMore.showlesscontent .readLess {
        display: none;
    }

    .addReadMore.showmorecontent .readMore {
        display: none;
    }

    .addReadMore .readMore,
    .addReadMore .readLess {
        font-weight: bold;
        margin-left: 2px;
        font-size:12px;
        color: #337ab7;
        cursor: pointer;
    }

    .addReadMoreWrapTxt.showmorecontent .SecSec,
    .addReadMoreWrapTxt.showmorecontent .readLess {
        display: block;
    }
    .SecSec{
        font-size:15px;
    }
    .educationarray{
        font-size:13px !important;
    }
    .show-more {
  display: none;
  cursor: pointer;
  color:#337ab7;
  font-size:12px;
}
    </style>
						<script>

function AddReadMore() {
    if ($('.educationarray').length > 3) {
  $('.educationarray:gt(2)').hide();
  $('.show-more').show();
   var readMoreTxt = " ... Know More";
    // Text to show when text is expanded
    var readLessTxt = " Know Less";
}
   
}
$('.show-more').on('click', function() {
  //toggle elements with class .ty-compact-list that their index is bigger than 2
  $('.educationarray:gt(2)').toggle();
  //change text of show more element just for demonstration purposes to this demo
  $(this).text() === 'Show more' ? $(this).text('Show less') : $(this).text('Show more');
});
$(function() {
    //Calling function after Page Load
    AddReadMore();
});

</script>