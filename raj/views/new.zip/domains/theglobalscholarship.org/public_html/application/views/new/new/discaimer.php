
<!--/.page-heading-area-->
<!--====================================Ambassador Section====================================-->
<section id="services-section" class="services-section-area s-pd1" style="background: #ffff !important; padding-bottom:18px">
   <div class="container">
      <div class="row justify-content-md-center">
         <div class="col-lg-12">
            <h1 class="" align="center">Disclaimer </h1>
            <br>
            <!--<h2>Disclaimer for Triwits Technologies Pvt. Ltd.</h2>-->
            
            <div class="row">
            <div class="col-lg-12">
            <p style="line-height:40px ">
             If you require any more information or have any questions about our site's disclaimer, please feel free to contact us by email at support@theglobalscholarship.org.
            </p>
            </div>
            </div>  
            <div class="container">
            </div>
            <div class="responsibilities">
               <h1 class="">Disclaimers for The Global Scholarship</h1>
               <!--<h3 class="page-heading" style="color: #ff7f45;">Ambassador</h3>-->
               <p class="" style="line-height:40px ">
                 All the information on this website - https://www.theglobalscholarship.org/ - is published in good faith and for general information purpose only. The Global Scholarship does not make any warranties about the completeness, reliability and accuracy of this information. Any action you take upon the information you find on this website (The Global Scholarship), is strictly at your own risk. The Global Scholarship will not be liable for any losses and/or damages in connection with the use of our website.
               </p>
             <p style="line-height:40px ">
                 From our website, you can visit other websites by following hyperlinks to such external sites. While we strive to provide only quality links to useful and ethical websites, we have no control over the content and nature of these sites. These links to other websites do not imply a recommendation for all the content found on these sites. Site owners and content may change without notice and may occur before we have the opportunity to remove a link which may have gone 'bad'.
             </p>
             <p style="line-height:40px ">Please be also aware that when you leave our website, other sites may have different privacy policies and terms which are beyond our control. Please be sure to check the Privacy Policies of these sites as well as their "Terms of Service" before engaging in any business or uploading any information.</p>
     
            </div>
            <div class="responsibilities">
               <h1 class="">Consent</h1>
               <!--<h3 class="page-heading" style="color: #ff7f45;">Structure</h3>-->
               <p class="" style="line-height:40px ">
                By using our website, you hereby consent to our disclaimer and agree to its terms. 
               </p>

            </div>
             <div class="responsibilities">
               <h1 class="">Update</h1>
               <!--<h3 class="page-heading" style="color: #ff7f45;">Structure</h3>-->
               <p class="" style="line-height:40px ">
               Should we update, amend or make any changes to this document, those changes will be prominently posted here. 
               </p> 
            </div>
         </div>
      </div>
   </div>
</section>
