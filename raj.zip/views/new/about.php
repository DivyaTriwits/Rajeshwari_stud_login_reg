<style>
    h1{
        color:#000000;
    }
   /*  ul li{
        color:#000000 !important;
    }*/
    .dot {
  height: 7px;
  width: 7px;
  background-color: #000000;
  border-radius: 50%;
  display: inline-block;
}
</style>
<!--/.page-heading-area-->
<!--====================================Ambassador Section====================================-->
<div style="background-color:#F2B625 !important">
<section id="services-section" class="services-section-area s-pd1" style="background: #F2B625 !important; padding-bottom:18px">
   <div class="container">
      <div class="row justify-content-md-center">
         <div class="col-lg-12">
            <br>
            <h1 class="" style="color:#410441">About Us</h1>
            <br>
            <div class="row">
            <div class="col-lg-12">
               <p style="line-height:40px ">
               <a href="https://www.theglobalscholarship.org/">The Global Scholarship</a> is one-stop solution through which various Education Funding services are provided starting from getting scholarship details to the Disbursal of various scholarship Rewards to students are enabled .
            </p>
            
            <p style="line-height:40px ">
            The Global Scholarship is <a href="https://www.theglobalscholarship.org/scholarships/Scholarship">Online Scholarship</a> Website that envisioned to bridge the gap between the top scholarship providers , and the scholarship seekers thus , encouraging more students to be in system. we have built solid relationships with colleges and universities across the country , We Help You to Find Investors for Your “Future!”.
            </p>
            <p style="line-height:40px ">
            Whether you're a prospective engineering student, undergraduate, diploma student, or medical student, we've got you covered! Our online scholarship website is designed to bridge the gap between top scholarship providers and seekers, making it easier for you to find the funding you need to achieve your academic goals. Our hardworking dedicated team do check recent scholarship news and adds, and updates scholarships in our database daily to make students aware of new scholarship opportunities.
            </p>
            <p style="line-height:40px ">
                we respond to feedback or solve the queries quickly.
            </p>
            <p style="line-height:40px ">
            The Global Scholarship" platform provides all scholarship details and guide students step by step with Easy Procedures in the whole scholarship application process by creating appropriate videos , which can refer to apply for scholarships easily with free of cost .

                </p>
                <p style="line-height:40px ">
                We are also the winners of Amrita Startups 2021 with 1400+ applications, the most ever , Were examined by 400+ independent jury members in 144 panels across 12 sectors. Only 107 applications were selected from distinct sectors. and we are one of them.
                    </p>
                    <h5 align="center" style="color:black;padding-top:20px"> "The Global Scholarship”  is  backed by Karnataka State Government . </h5>
            </div>
            </div>
          <!--    <div class="">
               
               <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322"
     crossorigin="anonymous"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="4041077001"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
            </div> -->
            
            <div class="responsibilities">
               <h1 class="">Mission</h1>
              
               <p class="" style="line-height:40px ">
                 Our mission is to empower students to reach their full potential by making education accessible and affordable for all. 
               </p>
                    
                   
            </div>
            <div class="responsibilities">
               <h1 class="">Vision</h1>
              
               <p class="" style="line-height:40px ">
                  Our vision is to build the world's largest student community, and help them find the right scholarships, Universities and more.
               </p>
               <br>
               <h1 class="">How The Global Scholarship Works: </h1>
               
                   <p class="" style="line-height:40px;margin-left: 20px;list-style: disc outside;"> <span class="dot"></span>
                        A team dedicatedly curates the available scholarship by cross checking facts and verifying with the concerned authorities. 
                            </p>
                   <p class="" style="line-height:40px;margin-left: 20px;"> <span class="dot"></span> Here , a dedicated  team  sets  reviews , updates  and  adds  scholarship</p>
                   <p class="" style="line-height:40px;margin-left: 20px; "> <span class="dot"></span> We personalise  new  scholarship  opportunities  and  deadline  notification to students  email id  , and  through telegram .</p>
                   <p class="" style="line-height:40px;margin-left: 20px; "> <span class="dot"></span>  Segregates every details required for students for filling up the Scholarship application form</p>
                   <p class="" style="line-height:40px;margin-left: 20px; "> <span class="dot"></span> We make sure that each and  every details of scholarships will be posted on our  <a href="https://www.instagram.com/the_global_scholarship/" target=_bank><u style="color:blue">Instagram page</u></a>,so follow us for more updates .</p>
              
               <br>
            </div>
            
         </div>
      </div>
   </div>
</section>

<!-- <section id="contact services-section " class="services-section-area s-pd1" style="background: #F2B625 !important; padding-top:10px !important">
   <div class="container" id="contact">
      <div class="row justify-content-md-center">
         <div class="col-lg-12"> -->
           
             <!-- About us - Responsive 1 -->
<!-- <ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8408941960924322"
     data-ad-slot="1941527275"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
            
          
            
         </div>
      </div>
   </div>
</section> -->
</div>