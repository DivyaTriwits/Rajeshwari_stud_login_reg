<style>.product-new{background:#fff;border-radius:50%;color:#fff;font-size:11px;font-weight:600;height:42px;right:0;line-height:42px;position:absolute;text-align:center;text-shadow:1px 2px 1px rgb(0 0 0 / 14%);top:0;width:42px;z-index:5}.product-sale-off{background:red;border-radius:10px 0 0;bottom:62px;color:#fff;font-size:12px;font-weight:500;height:25px;position:absolute;right:0;text-align:center;text-shadow:1px 2px 1px rgb(0 0 0 / 14%);width:100px;z-index:5}h1{color:#41044d}.btn-primary{background-color:#41044d;border-color:#41044d;color:#F2B625!important}.Add{margin-top:72px;background-color:#ff7f45;height:260px;width:300px;background-image:url(assets/images/add/ads-logo.png);background-size:100% 100%}.wrapper{margin:50px auto;width:280px;height:370px;background:white;border-radius:10px;-webkit-box-shadow:0 0 8px rgba(0,0,0,0.3);-moz-box-shadow:0 0 8px rgba(0,0,0,0.3);box-shadow:0 0 8px rgba(0,0,0,0.3);position:relative;z-index:90}.ribbon-wrapper-red{width:85px;height:88px;overflow:hidden;position:absolute;top:-3px;right:-3px}.ribbon-wrapper-green{width:85px;height:88px;overflow:hidden;position:absolute;top:-3px;left:-3px}.ribbon-red{font:bold 15px Sans-Serif;color:#fff;text-align:center;text-shadow:rgba(255,255,255,0.5) 0 1px 0;-webkit-transform:rotate(45deg);-moz-transform:rotate(45deg);-ms-transform:rotate(45deg);-o-transform:rotate(45deg);position:relative;padding:4px 0;left:-5px;top:15px;width:120px;background-color:#ea181e;background-image:-webkit-gradient(linear,left top,left bottom,from(#ea181e),to(#b90005));background-image:-webkit-linear-gradient(top,#ea181e,#b90005);background-image:-moz-linear-gradient(top,#BFDC7A,#8EBF45);background-image:-ms-linear-gradient(top,#BFDC7A,#8EBF45);background-image:-o-linear-gradient(top,#BFDC7A,#8EBF45);color:#fff;-webkit-box-shadow:0 0 3px rgba(0,0,0,0.3);-moz-box-shadow:0 0 3px rgba(0,0,0,0.3);box-shadow:0 0 3px rgba(0,0,0,0.3)}.ribbon-green{font:bold 15px Sans-Serif;color:#fff;text-align:center;text-shadow:rgba(255,255,255,0.5) 0 1px 0;-webkit-transform:rotate(-45deg);-moz-transform:rotate(-45deg);-ms-transform:rotate(-45deg);-o-transform:rotate(-45deg);position:relative;padding:4px 0;left:-29px;top:1px;border:1px solid;width:120px;background-color:#ff8c00;background-image:-webkit-gradient(linear,left top,left bottom,from(#FF8C00),to(#FF8C00));background-image:-webkit-linear-gradient(top,#FF8C00,# #FF8C00);background-image:-moz-linear-gradient(top,#BFDC7A,#8EBF45);background-image:-ms-linear-gradient(top,#BFDC7A,#8EBF45);background-image:-o-linear-gradient(top,#BFDC7A,#8EBF45);color:#fff;-webkit-box-shadow:0 0 3px rgba(0,0,0,0.3);-moz-box-shadow:0 0 3px rgba(0,0,0,0.3);box-shadow:0 0 3px rgba(0,0,0,0.3)}.ribbon-red:before,.ribbon-red:after{content:"";border-top:3px solid #b90005;border-left:3px solid transparent;border-right:3px solid transparent;position:absolute;bottom:-3px}.ribbon-green:after,.ribbon-green:after{content:"";border-top:3px solid #6e8900;border-left:3px solid transparent;border-right:3px solid transparent;position:absolute;bottom:-3px}.ribbon-red:before{left:0}.ribbon-green:before{right:0}.ribbon-red:after{right:0}.ribbon-green:after{left:0}.page-item:first-child .page-link{border-radius:6px 0 0 6px}.page-item.active .page-link{color:#fff}.page-item.active .page-link{z-index:2;color:#fff;background-color:#41044d;border-color:#41044d}.pagination>li>a,.pagination>li>span{position:relative;float:left;padding:5px 5px;margin-left:-1px;line-height:1.42857143;color:#41044d;text-decoration:none;background-color:#fff;border:1px solid #ddd}</style>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322" crossorigin="anonymous"></script>
<div style="background-color:#F2B625!important">
<section id="courses-section" class="popular-courses-area">
<div class="container" style="padding-top:38px!important">
<div class="row justify-content-md-center">
<div class="col-lg-12">
<div class="text-center">
<h1 class="text-capitalize section-heading" style="margin-bottom:30px">
Scholarships 2023
</h1>
</div>
</div>
</div>
<div class="text-center">
<div class="Addbox text-center mobile-card">
<div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322" crossorigin="anonymous"></script>
<ins class="adsbygoogle" style="display:inline-block;width:300px;height:250px" data-ad-client="ca-pub-8408941960924322" data-ad-slot="4904725821"></ins>
<script>(adsbygoogle=window.adsbygoogle||[]).push({});</script>
</div>
<br>
</div>
</div>
<div class="row">
<?php $index =1; $node=1; foreach($scholarships as $value): 
			    
			    if($node == 1){
			        $node+=1;
			    }
			    
			?>
<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12">
<div class="card card-height" style="border-color:#41044d;border-width:2px">
<div class="card-header custom-card-header border-bottom-0" style="">
<h4 class="main-content-label tx-dark tx-medium mb-0 font addReadMore showlesscontent">
<?=$value->scholarship_name;?>
</h4>
</div>
<div class="card-body card-content">
<?php $str= $value->application_start_date; //echo date("d-m-Y", strtotime($str)); ?>
<!-- <h6 class="card-h6-content">
<div class="media-icon-card icon-margin bg-primary-transparent text-danger" style="font-size:12px;margin-right:4px"> <i class="ti-calendar"></i>
</div>
<?=$str= $value->application_end_date;
										$month =date("F", strtotime($str));
							$result = substr($month, 0, 3);
							date("d", strtotime($str)).' '.$result.' '.date("Y", strtotime($str)) ; ?>
</h6> -->
<?php if($value->scholarship_worth !=0){?>
<h6 class="card-h6-content">
<div class="media-icon-card icon-margin bg-primary-transparent text-primary" style="font-size:12px;margin-right:4px"> <i class="fa fa-rupee"></i>
</div>
<?=$amount = $value->scholarship_worth+0;
                               $new=(int)$value->scholarship_worth;
                               $newworthamout=$this->New_model->moneyFormatIndia($new);
							$newworthamout; ?>
</h6>
<?php }else if($value->benefits != ''){?>
<h6 class="card-h6-content">
<div class="media-icon-card icon-margin bg-primary-transparent text-primary" style="font-size:12px;margin-right:4px"> <i class="fa fa-rupee"></i>
</div>
<?=$value->benefits; ?>
</h6>
<?php }?>
<h6 class="card-h6-content">
<div class="media-icon-card icon-margin bg-primary-transparent text-primary" style="font-size:12px;margin-right:4px"> <i class="fa fa-graduation-cap"></i>
</div>
<div class="addEducationReadMore showEducationlesscontent">
<?php $i = 0;
							 $course = json_decode($value->courses);
                              $len = count($course);
							 foreach($course as $course){?>
<?php if ($i == $len - 1) {?>
<a class="educationarray"><?=$course ; ?></a>
<?php } else {?>
<a class="educationarray"><?=$course ; ?>,</a>
<?php }?>
<?php $i++; }?>
</div>
</h6>
</div>
<div class="card-footer">
<?php if($value->h_tags !=''){
                        $newname =str_replace(' ', '-', strtolower($value->h_tags));
                        }else{
                        $newname =str_replace(' ', '-', strtolower($value->scholarship_name));
                        }
                      ?>
<a href="<?=base_url('page/'.$value->scholarship_id.'/'.$newname)?>" class="btn btn-primary ripple btn-block">View</a>
</div>
</div>
</div>
<?php if($index == $node){?>
<div class="col-lg-12 col-xl-4 col-md-12 col-12 col-sm-12 mobile-ad" style="padding-bottom:18px">
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8408941960924322" crossorigin="anonymous"></script>
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-8408941960924322" data-ad-slot="4868051162" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>(adsbygoogle=window.adsbygoogle||[]).push({});</script>
</div>
<?php $node+=3;}?>
<?php $index++; endforeach; ?>
</div>
</div>
<style>@media(max-width :480px){.mobile-ad{display:block!important;width:auto}}.mobile-ad{display:none}</style>
<div class="addbox" id="fadd" style="padding-top:38px!important">
<div class="Add" style="height:300px!important;border-radius:14px!important;background-color:#ffff">
</div>
<div class="Add" style="height:300px!important;border-radius:14px!important;margin-top:26px;background-color:#ffff">
<ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-8408941960924322" data-ad-slot="4137016599" data-ad-format="auto" data-full-width-responsive="true"></ins>
<script>(adsbygoogle=window.adsbygoogle||[]).push({});</script>
</div>
</div>
</div>
<style>@media(min-width:1200px){.container{max-width:1400px}.mobilecate{display:none}#padinations{display:none}}.container{margin-left:0}.card-height{height:280px!important}.card-header{max-height:35px;margin-bottom:30px}@media only screen and (max-width:600px){.card-height{height:auto!important}.addbox{display:none}.desktopcate{display:none!important}#padinations{display:block!important}#deskview{display:none!important}#mobileview{display:block!important}.mobilecate{display:block!important}}@media screen and (max-width:650px){.card-height{height:auto!important}.addbox{display:none}.desktopcate{display:none!important}#padinations{display:block!important}#deskview{display:none!important}#mobileview{display:block!important}.mobilecate{display:block!important}}@media(max-width:400px){#deskview{display:none!important}#mobileview{display:block!important}.desktopcate{display:none!important}#padinations{display:block!important}.mobilecate{display:block!important}}</style>
<style>.addReadMore.showlesscontent .SecSec,.addReadMore.showlesscontent .readLess{display:none}.addReadMore.showmorecontent .readMore{display:none}.addReadMore .readMore,.addReadMore .readLess{font-weight:bold;margin-left:2px;font-size:12px;color:#337ab7;cursor:pointer}.addReadMoreWrapTxt.showmorecontent .SecSec,.addReadMoreWrapTxt.showmorecontent .readLess{display:block}.SecSec{font-size:15px}.addEducationReadMore.showEducationlesscontent .EducationSecSec,.addEducationReadMore.showEducationlesscontent .readEducationLess{display:none}.addEducationReadMore.showEducationmorecontent .readEducationMore{display:none}.addEducationReadMore .readEducationMore,.addEducationReadMore .readEducationLess{font-weight:bold;margin-left:2px;font-size:12px;color:#337ab7;cursor:pointer}.addEducationReadMoreWrapTxt.showEducationmorecontent .EducationSecSec,.addEducationReadMoreWrapTxt.showEducationmorecontent .readEducationLess{display:block}.EducationSecSec{font-size:15px}</style>