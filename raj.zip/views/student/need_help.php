<!-- Main Content-->
<div class="main-content pt-4 mt-5">
	<div class="container fuild">

		<!-- Page Header -->
		<!-- <div class="text-wrap">
			<div class="example">
				<nav aria-label="breadcrumb">
					<ol class="breadcrumb breadcrumb-style1 mg-b-0">


						<li class="breadcrumb-item">
							<a href="<?php echo base_url()?>">Home</a></li>
							<li class="breadcrumb-item active">Need Help</li>
						</ol>
					</nav>
				</div>
			</div> -->
			<!-- End Page Header -->
			
			<!-- Row -->
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="card">
						<div class="card-body" >
							<!-- <div> -->
								<h6 class="main-content-label mb-1">You can also contact us on below details</h6><br>
								<!-- </div> -->
								<!-- Row -->
								<div class="row">
									<div class="col-lg-6 col-md-6 col-sm-12 col-xl-4">
										<div class="card overflow-hidden">
											<div class="">

												<div class="row">
													<div class="col-12">
														<div class=" p-4 " style="background-color:#ff7f45">
															<div class="text-center text-white social">
																<i class="fe fe-phone" style="color: #ffffff"></i>
															</div>
														</div>
													
													</div> 
													<div class="card-body mt-0">
													<!-- <div class="d-flex  align-items-center"  > -->
														<div style="text-align: center;">
															<div >
												

														<strong>+919916056303<br>

															<a  target = "_blank" href="tel:+919916056303"><i style="font-size: 25px"class="fe fe-phone"></i></a> or 

															<a   target = "_blank"
														href="https://api.whatsapp.com/send/?phone=+919916056303" data-action="share/whatsapp/share"><i class="zmdi zmdi-whatsapp"style="font-size: 25px;color:green"></i></a></strong>
													</div>
													
													</div>
												</div>
												</div>
											</div>
										</div>
									</div>
								
							<!-- </div> -->
							<!-- <div class="col-lg-6 col-md-6 col-sm-12 col-xl-3">
								<div class="card overflow-hidden">
									<div class="">
										<div class="row">
											<div class="col-12">
												<div class="twitter p-4 " style="background-color:#ff7f45">
													<div class="text-center text-white social">
														<i class="fe fe-phone" style="color: #ffffff"></i>
													</div>
												</div>
												<div class="card-body mt-0">
													<div class="d-flex  align-items-center">
														<div>
														

																<strong><a  target = "_blank" href="tel:+918892278892">+918892278892</a></strong>&nbsp;&nbsp;

															</div>
															<div class="ml-auto">
																<strong><a  target = "_blank" href="tel:+919620030302">+919620030302</a>	</strong>
														
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div> -->
							<div class="col-lg-6 col-md-6 col-sm-12 col-xl-4">
								<div class="card overflow-hidden">
									<div class="">
										<div class="row">
											<div class="col-12">
												<div class=" p-4 " style="background-color:#ff7f45" >
													<div class="text-center text-white social">
														<i class="fe fe-mail" style="color: #ffffff"></i>
													</div>
												</div>
												<div class="card-body mt-0">
													<!-- <div class="d-flex  align-items-center"  > -->
														<div style="text-align: center;">
															<div >
													<!-- 		<h3 class="font-weight-semibold mb-1">76k</h3>
														<h5 class="text-muted mb-0">Following</h5> -->

														<strong><a  target = "_blank" href="mailto:support@theglobalscholarship.org">support@theglobalscholarship.org</a>	</strong>
													</div>
													<!-- 	<div class="ml-auto">
															<h3 class="font-weight-semibold mb-1">27k</h3>
															<h5 class="text-muted mb-0">Friends</h5>
														</div> -->
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xl-4">
								<div class="card overflow-hidden">
									<div class="">
										<div class="row">
											<div class="col-12">
												<div class=" p-4 " style="background-color:#ff7f45" >
													<div class="text-center text-white social">
														<i class="fe fe-monitor" style="color: #ffffff"></i>
													</div>
												</div>
												<div class="card-body mt-0">
													<!-- <div class="d-flex  align-items-center"  > -->
														<div style="text-align: center;">
															<div >
													<!-- 		<h3 class="font-weight-semibold mb-1">76k</h3>
														<h5 class="text-muted mb-0">Following</h5> -->

														<strong>Install AnyDesk in <br><a target="_blank" href="https://play.google.com/store/apps/details?id=com.anydesk.anydeskandroid"><i style="font-size: 30px" class="fe fe-smartphone"></i></a> or <a target="_blank" href="https://anydesk.com/en"><i style="font-size: 30px" class="fe fe-monitor"></i></a></strong>
													</div>
													<!-- 	<div class="ml-auto">
															<h3 class="font-weight-semibold mb-1">27k</h3>
															<h5 class="text-muted mb-0">Friends</h5>
														</div> -->
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>

		<!-- Row -->
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="card">
					<div class="card-body" >
						<!-- <div> -->
							<a class="btn ripple pull-right" href="<?php echo base_url()?>view-response" style="background-color:#460056;border-color:#460056">View Response</a>	

							<h6 class="main-content-label mb-1">Request Call Back</h6>
							<!-- </div> -->


							<form id="contactForm" method="Post" action="<?php echo base_url('add-contact-us')?>">
								<div class="row">
									<!-- <div class="col-md-3">
										<div class="form-group">
											<p class="mg-b-10">Your Name</p>
											<input type="text" name="name" class="form-control">
										</div>
									</div> -->
								<!-- 	<div class="col-md-3">
										<div class="form-group">
											<p class="mg-b-10">Your Contact Number</p>
											<input type="text" name="number" class="form-control">
										</div>
									</div> -->
									<div class="col-md-12">
										<div class="form-group">
											<p class="mg-b-10">Your Message</p>
											<textarea type="text" name="message" class="form-control"></textarea>
										</div>
									</div>
								</div>
								<button style="background-color: #ff7f45; border-color: #ff7f45" type="submit" class="btn ripple btn-primary float-right">Submit</button>
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- Row -->
		<!-- <a href="<?php echo base_url('help')?>">
			<button type="button" class="btn ripple btn-dark float-left" style="margin-right: 5px;background-color:#460056;border-color:#460056">Back</button>
		</a> -->

	</div>

<!-- Row -->




<?php if($this->session->flashdata('update-success')){?>		
	<Script>
		swal({
			title: 'Well done!',
			text: 'Message Sent Successfully! You will get response soon',
			type: 'success',
			timer: 3000,
			showConfirmButton: false
		});
	</Script>
<?php }?>

<?php if($this->session->flashdata('update-error')){?>		
	<Script>
		swal({
			title: 'Information!',
			text: 'Please enter the message',
			type: 'info',
			timer: 3000,
			showConfirmButton: false
		});
	</Script>
<?php }?>


<script>
	$(document).ready(function() {
		$('#contactForm').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
        // 	valid: 'glyphicon glyphicon-ok',
        // 	invalid: 'glyphicon glyphicon-remove',
        // 	validating: 'glyphicon glyphicon-refresh'
    },
    fields: {

    	name: {
    		validators: {
    			notEmpty: {
    				message: 'Name is required'
    			},

        			// regexp: {
        			// 	regexp: /[0-9]/,
        			// 	message: ' <br >The conatct number can only consist of digits'
        			// }
        		}
        	},
        	number: {
        		validators: {
        			notEmpty: {
        				message: 'The contact number is required'
        			},
        			stringLength: {
        				min: 10,
        				max: 10,
        				message: 'The contact number. must be 10 digits'
        			},
        			regexp: {
        				regexp: /[0-9]/,
        				message: ' <br >The conatct number can only consist of digits'
        			}
        		}
        	}          
        }
    }).on('success.form.bv', function(e) {
    	$(this)[0].submit();

    });                             
});
</script>